#ifndef BOARD_PINS_H_
#define BOARD_PINS_H_

#include "IfxPort.h"
#include "IfxGtm.h"
#include "Vadc/Std/IfxVadc.h"

/* ============================================================================================= */
/* USER VEHICLE - FINAL LOWER CONTROL PIN MAP                                                     */
/* ============================================================================================= */

/* LEFT MOTOR - D50A */
#define LEFT_INA_PORT                  (&MODULE_P33)
#define LEFT_INA_PIN                   ((uint8)7)
#define LEFT_INB_PORT                  (&MODULE_P33)
#define LEFT_INB_PIN                   ((uint8)5)
#define LEFT_PWM_PIN                   (&IfxGtm_TOM1_0_TOUT9_P00_0_OUT)

/* RIGHT MOTOR - D50A */
#define RIGHT_INA_PORT                 (&MODULE_P33)
#define RIGHT_INA_PIN                  ((uint8)4)
#define RIGHT_INB_PORT                 (&MODULE_P33)
#define RIGHT_INB_PIN                  ((uint8)6)
#define RIGHT_PWM_PIN                  (&IfxGtm_TOM1_1_TOUT11_P00_2_OUT)

/*
 * LEFT ENCODER
 * Existing wiring already matches GPT12 T3 incremental interface:
 *   A = P02.6 = T3INA
 *   B = P02.7 = T3EUDA
 */
#define LEFT_ENC_A_PORT                (&MODULE_P02)
#define LEFT_ENC_A_PIN                 ((uint8)6)
#define LEFT_ENC_B_PORT                (&MODULE_P02)
#define LEFT_ENC_B_PIN                 ((uint8)7)

/*
 * RIGHT ENCODER - FINAL GPT12 HARDWARE COUNTER WIRING
 *
 * IMPORTANT HARDWARE CHANGE FROM CURRENT TEST WIRING:
 *   OLD: A=P33.3, B=P00.9
 *   NEW: A=P00.7, B=P00.8
 *
 * Reason:
 *   P00.7/P00.8 form a valid GPT12 T2 incremental-interface pair.
 *   The old P33.3/P00.9 pair cannot be used as one GPT12 quadrature pair.
 */
#define RIGHT_ENC_A_PORT               (&MODULE_P00)
#define RIGHT_ENC_A_PIN                ((uint8)7)
#define RIGHT_ENC_B_PORT               (&MODULE_P00)
#define RIGHT_ENC_B_PIN                ((uint8)8)

/* Steering servo */
#define SERVO_PWM_PIN                  (&IfxGtm_TOM0_8_TOUT8_P02_8_OUT)

/* Steering potentiometer */
#define POT_ADC_GROUP_ID               IfxVadc_GroupId_0
#define POT_ADC_CHANNEL_ID             IfxVadc_ChannelId_1
#define POT_ADC_RESULT_REGISTER        IfxVadc_ChannelResult_1

/* PS2 receiver - mikroBUS */
#define PS2_DATA_PORT                  (&MODULE_P10)
#define PS2_DATA_PIN                   ((uint8)1)
#define PS2_CMD_PORT                   (&MODULE_P10)
#define PS2_CMD_PIN                    ((uint8)3)
#define PS2_ATT_PORT                   (&MODULE_P10)
#define PS2_ATT_PIN                    ((uint8)0)
#define PS2_CLK_PORT                   (&MODULE_P10)
#define PS2_CLK_PIN                    ((uint8)2)

/* Optional debug pin: GPT12 100 us ISR toggle */
#define ISR_CHECK_PORT                 (&MODULE_P10)
#define ISR_CHECK_PIN                  ((uint8)4)

#endif /* BOARD_PINS_H_ */
