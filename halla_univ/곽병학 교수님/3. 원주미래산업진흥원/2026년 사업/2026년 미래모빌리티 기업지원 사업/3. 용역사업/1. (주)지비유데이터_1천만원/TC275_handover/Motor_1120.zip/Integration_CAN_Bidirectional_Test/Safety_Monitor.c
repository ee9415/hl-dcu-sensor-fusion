#include "Safety_Monitor.h"
#include "Safety_Config.h"
#include "IfxCpu.h"
#include "IfxScuWdt.h"
#include "IfxScuCcu.h"
#include "GPT12_Timer_Interrupt.h"
#include "Can_VehicleControl.h"

volatile uint8  g_watchdogEnabled = 0U;
volatile uint32 g_watchdogReload = 0U;
volatile uint32 g_resetStatusRaw = 0U;
volatile uint32 g_loopOverrunCount = 0U;
volatile uint32 g_loopOverrunFaultCount = 0U;
volatile uint8  g_loopMaxBacklog = 0U;
volatile uint32 g_loopExecTimeUs = 0U;
volatile uint32 g_loopMaxExecTimeUs = 0U;

static uint32 s_loopStartTick = 0U;
static uint32 s_startTick = 0U;

/*
 * Reload value for the requested timeout.
 * The CPU watchdog counts up from REL to 0xFFFF at fSPB / 16384
 * (startup default input divider).
 */
static uint16 SafetyMonitor_CalcReload(uint32 timeoutMs)
{
    float32 ticks;
    uint32 t;

    ticks = (IfxScuCcu_getSpbFrequency() / 16384.0f) * ((float32)timeoutMs / 1000.0f);
    t = (uint32)ticks;

    if (t < 2U)
    {
        t = 2U;
    }
    if (t > 0xFFF0U)
    {
        t = 0xFFF0U;
    }

    return (uint16)(0x10000U - t);
}

void SafetyMonitor_Start(void)
{
    g_resetStatusRaw = MODULE_SCU.RSTSTAT.U;

    s_startTick = g_tick100us;
    s_loopStartTick = g_tick100us;

#if (WATCHDOG_ENABLE != 0U)
    {
        uint16 password;
        uint16 reload;

        password = IfxScuWdt_getCpuWatchdogPassword();
        reload = SafetyMonitor_CalcReload(WATCHDOG_TIMEOUT_MS);

        IfxScuWdt_changeCpuWatchdogReload(password, reload);
        IfxScuWdt_enableCpuWatchdog(password);
        IfxScuWdt_serviceCpuWatchdog(password);

        g_watchdogReload = reload;
        g_watchdogEnabled = 1U;
    }
#else
    (void)SafetyMonitor_CalcReload;
#endif
}

void SafetyMonitor_LoopBegin(void)
{
    boolean interruptState;
    uint8 backlog;

    s_loopStartTick = g_tick100us;

    /* Ticks still pending after Take5msFlag() consumed one = lateness. */
    interruptState = IfxCpu_disableInterrupts();
    backlog = g_flag5ms;
    if (backlog >= LOOP_OVERRUN_FAULT_BACKLOG)
    {
        /* Do not burst-run stale iterations back to back. */
        g_flag5ms = 0U;
    }
    IfxCpu_restoreInterrupts(interruptState);

    if (backlog != 0U)
    {
        g_loopOverrunCount++;

        if (backlog > g_loopMaxBacklog)
        {
            g_loopMaxBacklog = backlog;
        }

        if (backlog >= LOOP_OVERRUN_FAULT_BACKLOG)
        {
            g_loopOverrunFaultCount++;
            /* Latched FAULT: motor stop, SELECT returns to MANUAL. */
            CanVehicleControl_EmergencyStop();
        }
    }
}

void SafetyMonitor_LoopEnd(void)
{
    uint32 execUs;

    execUs = (g_tick100us - s_loopStartTick) * 100U;
    g_loopExecTimeUs = execUs;
    if (execUs > g_loopMaxExecTimeUs)
    {
        g_loopMaxExecTimeUs = execUs;
    }

#if (WATCHDOG_TEST_HANG_AFTER_MS != 0U)
    if ((g_tick100us - s_startTick) >= ((uint32)WATCHDOG_TEST_HANG_AFTER_MS * 10U))
    {
        /* Bench test: stop servicing the watchdog forever. */
        while (1)
        {
        }
    }
#endif

#if (WATCHDOG_ENABLE != 0U)
    IfxScuWdt_serviceCpuWatchdog(IfxScuWdt_getCpuWatchdogPassword());
#endif
}
