#ifndef GEAR_MANAGER_H_
#define GEAR_MANAGER_H_

#include "Ifx_Types.h"

typedef enum
{
    GearDriveMode_Forward = 0,
    GearDriveMode_Reverse = 1
} GearDriveMode;

void GearManager_Init(void);
void GearManager_GearUp(void);
void GearManager_GearDown(void);
void GearManager_Stop(void);
void GearManager_ToggleDriveMode(void);
float32 GearManager_GetTargetRpm(void);
float32 GearManager_GetSignedTargetRpm(void);
GearDriveMode GearManager_GetDriveMode(void);

extern volatile uint8 g_gear;
extern volatile uint8 g_driveMode;
extern volatile float32 g_targetRpm;
extern volatile float32 g_commandedSignedRpm;
uint8 GearManager_GetGear(void);

#endif /* GEAR_MANAGER_H_ */
