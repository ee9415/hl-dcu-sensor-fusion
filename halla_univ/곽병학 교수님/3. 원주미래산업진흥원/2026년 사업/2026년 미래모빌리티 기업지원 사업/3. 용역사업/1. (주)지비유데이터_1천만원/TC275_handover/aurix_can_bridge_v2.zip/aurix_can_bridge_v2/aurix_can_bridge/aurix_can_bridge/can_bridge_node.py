#!/usr/bin/env python3
"""ROS 2 <-> AURIX TC275 classic CAN bridge (SocketCAN, 500 kbit/s).

CAN 0x200 command (8 bytes, TC275 units):
  bytes 0..1 target RPM int16 LE, 2..3 steering deg int16 LE (+ = RIGHT),
  byte 4 enable (0/1), byte 5 stop mode (0; firmware ignores it),
  byte 6 alive counter (+1 every frame), byte 7 XOR of bytes 0..6.
CAN 0x101 steering feedback:
  bytes 0..1 requested steering int16 LE, 2..3 raw pot ADC uint16 LE,
  byte 4 ADC valid, byte 5 TC275 mode.
CAN 0x102 speed feedback:
  bytes 0..1 left RPM int16 LE, 2..3 right RPM int16 LE,
  bytes 4..5 vehicle RPM int16 LE, byte 6 RPM valid, byte 7 mode.

Inputs (both need allow_motion:=true AND an explicit ARM):
  /aurix/can/command (String) 'rpm,steering_deg,enable' in TC275 units
                     (steering + = right), or 'ARM' / 'DISARM'.
  /cmd_vel (Twist)   ROS units: linear.x m/s, angular.z rad/s (+ = left).
                     Converted with wheel diameter and wheelbase; the steering
                     sign is flipped for the TC275.

Uncalibrated potentiometer ADC counts must NOT be presented as an actual angle.
"""

import math
import struct
import time

import can
import rclpy
from geometry_msgs.msg import Twist
from rclpy.node import Node
from std_msgs.msg import Bool, Float32, String, UInt16


MODE_NAMES = {0: 'MANUAL', 1: 'AUTO', 2: 'FAULT', 3: 'STOPPING'}


def build_command_frame(rpm, steer_deg, enable, alive):
    """0x200 payload: <hhBB + alive counter + XOR checksum of bytes 0..6."""
    head = struct.pack('<hhBBB', rpm, steer_deg, enable, 0, alive & 0xFF)
    checksum = 0
    for byte in head:
        checksum ^= byte
    return head + bytes([checksum])


def twist_to_tc275(v, omega, wheel_diameter, wheelbase, max_speed, max_rpm,
                   max_steer_deg, allow_reverse, min_speed_for_steer):
    """ROS Twist -> (rpm, steer_deg) in TC275 units (steer + = right)."""
    if not math.isfinite(v) or not math.isfinite(omega):
        raise ValueError('non-finite cmd_vel')
    if v < 0.0 and not allow_reverse:
        v = 0.0
    v = max(-max_speed, min(max_speed, v))
    rpm = int(round(v / (math.pi * wheel_diameter) * 60.0))
    rpm = max(-max_rpm, min(max_rpm, rpm))

    if abs(v) < min_speed_for_steer:
        steer_ros_deg = 0.0        # cannot turn in place; keep wheels straight
    else:
        steer_ros_deg = math.degrees(math.atan(wheelbase * omega / v))
    steer_ros_deg = max(-max_steer_deg, min(max_steer_deg, steer_ros_deg))
    steer_tc275 = -int(round(steer_ros_deg))    # ROS + = left, TC275 + = right
    return rpm, steer_tc275


class AurixCanBridge(Node):
    def __init__(self):
        super().__init__('aurix_can_bridge')
        self.declare_parameter('can_interface', 'can0')
        self.declare_parameter('can_bustype', 'socketcan')
        self.declare_parameter('allow_motion', False)
        self.declare_parameter('command_timeout_sec', 0.20)
        self.declare_parameter('tx_period_sec', 0.02)
        self.declare_parameter('max_rpm', 140)
        self.declare_parameter('max_steer_deg', 24)
        self.declare_parameter('cmd_vel_topic', '/cmd_vel')
        self.declare_parameter('max_speed_mps', 0.30)
        self.declare_parameter('allow_reverse', False)
        self.declare_parameter('wheel_diameter_m', 0.18)
        self.declare_parameter('wheelbase_m', 0.59)
        self.declare_parameter('min_speed_for_steer_mps', 0.05)
        channel = str(self.get_parameter('can_interface').value)
        bustype = str(self.get_parameter('can_bustype').value)
        self.allow_motion = bool(self.get_parameter('allow_motion').value)
        self.command_timeout = float(self.get_parameter('command_timeout_sec').value)
        tx_period = float(self.get_parameter('tx_period_sec').value)
        self.max_rpm = int(self.get_parameter('max_rpm').value)
        self.max_steer = int(self.get_parameter('max_steer_deg').value)
        self.max_speed = float(self.get_parameter('max_speed_mps').value)
        self.allow_reverse = bool(self.get_parameter('allow_reverse').value)
        self.wheel_d = float(self.get_parameter('wheel_diameter_m').value)
        self.wheelbase = float(self.get_parameter('wheelbase_m').value)
        self.min_v_steer = float(self.get_parameter('min_speed_for_steer_mps').value)
        if not 0.05 <= self.command_timeout <= 1.0:
            raise ValueError('command_timeout_sec must be between 0.05 and 1.0')
        # Firmware faults if no 0x200 for 200 ms: keep at least 4 frames inside that.
        if not 0.01 <= tx_period <= 0.05:
            raise ValueError('tx_period_sec must be between 0.01 and 0.05')
        # Firmware rejects |rpm| > MAX_TEST_RPM (200) and steering outside STEERING_MIN/MAX.
        if not 0 <= self.max_rpm <= 200:
            raise ValueError('max_rpm must be between 0 and 200')
        if not 0 <= self.max_steer <= 24:
            raise ValueError('max_steer_deg must be between 0 and 24')
        if not 0.0 <= self.max_speed <= 1.0:
            raise ValueError('max_speed_mps must be between 0.0 and 1.0')

        self.bus = can.Bus(channel=channel, interface=bustype, receive_own_messages=False)
        self.steer_pub = self.create_publisher(String, '/aurix/can/steering_raw', 10)
        self.speed_pub = self.create_publisher(String, '/aurix/can/speed_raw', 10)
        # Decoded CAN feedback. Published only when the relevant valid flag is set.
        self.actual_rpm_pub = self.create_publisher(Float32, '/aurix/can/actual_rpm', 10)
        self.left_rpm_pub = self.create_publisher(Float32, '/aurix/can/left_rpm', 10)
        self.right_rpm_pub = self.create_publisher(Float32, '/aurix/can/right_rpm', 10)
        self.rpm_valid_pub = self.create_publisher(Bool, '/aurix/can/rpm_valid', 10)
        self.target_steer_pub = self.create_publisher(Float32, '/aurix/can/target_steering', 10)
        self.steering_adc_pub = self.create_publisher(UInt16, '/aurix/can/actual_steering_adc', 10)
        self.steering_valid_pub = self.create_publisher(Bool, '/aurix/can/steering_adc_valid', 10)
        self.control_mode_pub = self.create_publisher(String, '/aurix/can/control_mode', 10)
        self.command_sub = self.create_subscription(
            String, '/aurix/can/command', self.on_command, 10)
        self.cmd_vel_sub = self.create_subscription(
            Twist, str(self.get_parameter('cmd_vel_topic').value), self.on_cmd_vel, 10)

        self.armed = False
        self.command = (0, 0, 0)
        self.last_command_at = None
        self.alive = 0
        self.last_mode = None
        self.tx_timer = self.create_timer(tx_period, self.send_command)
        self.rx_timer = self.create_timer(0.01, self.receive_feedback)
        self.get_logger().info(
            f'CAN bridge on {channel}: 0x200 TX every {tx_period * 1000:.0f} ms / '
            f'0x101,0x102 RX. allow_motion={self.allow_motion}; '
            f'max_speed={self.max_speed} m/s, max_rpm={self.max_rpm}, '
            f'max_steer={self.max_steer} deg, allow_reverse={self.allow_reverse}; '
            f'initial command=0,0,0')

    def disarm(self, reason):
        was_armed = self.armed
        self.armed = False
        self.command = (0, 0, 0)
        self.last_command_at = None
        if was_armed:
            self.get_logger().warn(f'DISARMED: {reason}')

    def on_command(self, msg):
        raw = msg.data.strip()
        if raw.upper() == 'DISARM':
            self.disarm('explicit DISARM')
            return
        if raw.upper() == 'ARM':
            if not self.allow_motion:
                self.get_logger().warn('ARM rejected: allow_motion parameter is false')
                return
            self.command = (0, 0, 0)
            self.last_command_at = None
            self.armed = True
            self.get_logger().warn('ARMED: waiting for fresh command stream')
            return

        try:
            fields = raw.split(',')
            if len(fields) != 3:
                raise ValueError('expected rpm,steering_deg,enable')
            rpm, steer, enable = (int(s.strip()) for s in fields)
            if not (-self.max_rpm <= rpm <= self.max_rpm
                    and -self.max_steer <= steer <= self.max_steer
                    and enable in (0, 1)):
                raise ValueError(f'RPM must be -{self.max_rpm}..{self.max_rpm}, '
                                 f'steering -{self.max_steer}..{self.max_steer}, '
                                 'enable 0 or 1')
        except ValueError as exc:
            self.disarm('invalid command')
            self.get_logger().warn(f'Invalid CAN command {raw!r}: {exc}')
            return

        self.accept(rpm, steer, enable)

    def on_cmd_vel(self, msg):
        try:
            rpm, steer = twist_to_tc275(
                msg.linear.x, msg.angular.z, self.wheel_d, self.wheelbase,
                self.max_speed, self.max_rpm, self.max_steer,
                self.allow_reverse, self.min_v_steer)
        except ValueError as exc:
            self.disarm('invalid cmd_vel')
            self.get_logger().warn(f'Invalid cmd_vel: {exc}')
            return
        # Twist has no enable flag: v = 0 is sent as enable=1, rpm=0 (firmware ramp stop).
        self.accept(rpm, steer, 1)

    def accept(self, rpm, steer, enable):
        if enable == 0:
            self.command = (0, 0, 0)
            self.last_command_at = time.monotonic()
            return

        if not (self.allow_motion and self.armed):
            self.get_logger().warn('Motion command rejected: allow_motion=true and ARM required',
                                   throttle_duration_sec=2.0)
            return
        self.command = (rpm, steer, enable)
        self.last_command_at = time.monotonic()

    def send_command(self):
        if self.last_command_at is not None and self.command[2] == 1:
            if time.monotonic() - self.last_command_at >= self.command_timeout:
                self.disarm('command stream timeout')
        rpm, steer, enable = self.command
        if not (self.allow_motion and self.armed):
            rpm, steer, enable = 0, 0, 0
        self.send_frame(rpm, steer, enable)

    def send_frame(self, rpm, steer, enable):
        data = build_command_frame(rpm, steer, enable, self.alive)
        self.alive = (self.alive + 1) & 0xFF
        msg = can.Message(arbitration_id=0x200, is_extended_id=False, data=data)
        try:
            self.bus.send(msg, timeout=0.01)
        except can.CanError as exc:
            self.disarm('CAN TX failure')
            self.get_logger().error(f'CAN TX error: {exc}', throttle_duration_sec=2.0)

    def receive_feedback(self):
        try:
            for _ in range(32):
                msg = self.bus.recv(timeout=0.0)
                if msg is None:
                    break
                if msg.is_extended_id or msg.is_error_frame or len(msg.data) != 8:
                    continue
                if msg.arbitration_id not in (0x101, 0x102):
                    continue
                payload = String()
                payload.data = ' '.join(f'{byte:02X}' for byte in msg.data)
                (self.steer_pub if msg.arbitration_id == 0x101 else self.speed_pub).publish(payload)

                if msg.arbitration_id == 0x101:
                    requested_deg, adc_count = struct.unpack_from('<hH', msg.data, 0)
                    adc_valid = (msg.data[4] == 1)
                    self.target_steer_pub.publish(Float32(data=float(requested_deg)))
                    self.steering_valid_pub.publish(Bool(data=adc_valid))
                    if adc_valid:
                        self.steering_adc_pub.publish(UInt16(data=adc_count))
                else:  # 0x102
                    left_rpm, right_rpm, vehicle_rpm = struct.unpack_from('<hhh', msg.data, 0)
                    rpm_valid = (msg.data[6] == 1)
                    self.rpm_valid_pub.publish(Bool(data=rpm_valid))
                    if rpm_valid:
                        self.left_rpm_pub.publish(Float32(data=float(left_rpm)))
                        self.right_rpm_pub.publish(Float32(data=float(right_rpm)))
                        self.actual_rpm_pub.publish(Float32(data=float(vehicle_rpm)))
                    mode = MODE_NAMES.get(msg.data[7], f'UNKNOWN({msg.data[7]})')
                    self.control_mode_pub.publish(String(data=mode))
                    if mode != self.last_mode:
                        self.get_logger().info(f'TC275 mode: {mode}')
                        self.last_mode = mode
        except can.CanError as exc:
            self.disarm('CAN RX failure')
            self.get_logger().error(f'CAN RX error: {exc}', throttle_duration_sec=2.0)

    def destroy_node(self):
        self.tx_timer.cancel()
        self.rx_timer.cancel()
        # Several enable=0 frames (fresh alive counters) before closing the interface.
        # Firmware then ramp-stops; ~200 ms after the last frame it latches FAULT
        # if it is still in AUTO (press SELECT to return to MANUAL).
        for _ in range(5):
            try:
                self.bus.send(can.Message(arbitration_id=0x200, is_extended_id=False,
                                          data=build_command_frame(0, 0, 0, self.alive)),
                              timeout=0.01)
            except can.CanError:
                pass
            self.alive = (self.alive + 1) & 0xFF
            time.sleep(0.02)
        self.bus.shutdown()
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = AurixCanBridge()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
