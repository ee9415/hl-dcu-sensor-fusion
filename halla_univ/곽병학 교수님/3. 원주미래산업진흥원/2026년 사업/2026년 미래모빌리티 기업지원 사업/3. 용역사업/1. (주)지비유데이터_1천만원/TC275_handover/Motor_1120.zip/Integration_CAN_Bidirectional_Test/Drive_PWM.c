#include "Drive_PWM.h"

#include "App_Config.h"
#include "Board_Pins.h"
#include "IfxGtm.h"
#include "IfxGtm_Tom.h"
#include "IfxGtm_Tom_Pwm.h"
#include "IfxPort.h"

static IfxGtm_Tom_Pwm_Config g_leftPwmConfig;
static IfxGtm_Tom_Pwm_Driver g_leftPwmDriver;
static IfxGtm_Tom_Pwm_Config g_rightPwmConfig;
static IfxGtm_Tom_Pwm_Driver g_rightPwmDriver;

volatile float32 g_leftDutyPercent = 0.0f;
volatile float32 g_rightDutyPercent = 0.0f;
volatile uint8 g_driveDirectionDebug = 0U;
volatile uint8 g_motorRunning = 0U;

static float32 DrivePwm_LimitDuty(float32 duty)
{
    if (duty < MIN_DUTY_PERCENT)
    {
        duty = MIN_DUTY_PERCENT;
    }

    if (duty > MAX_DUTY_PERCENT)
    {
        duty = MAX_DUTY_PERCENT;
    }

    return duty;
}

static void DrivePwm_SetLeftDuty(float32 dutyPercent)
{
    uint32 dutyTicks;

    dutyPercent = DrivePwm_LimitDuty(dutyPercent);
    dutyTicks = (uint32)(((float32)MOTOR_PWM_PERIOD_TICKS * dutyPercent) / 100.0f);

    /* Runtime update: write SR1 shadow only. The GTM transfers it to CM1 at
     * the end of the current PWM period, so the period is never cut short.
     * PWM init/start happens once in DrivePwm_Init(). */
    IfxGtm_Tom_Ch_setCompareOneShadow(g_leftPwmDriver.tom,
                                      g_leftPwmDriver.tomChannel,
                                      (uint16)dutyTicks);
    g_leftPwmConfig.dutyCycle = dutyTicks;

    g_leftDutyPercent = dutyPercent;
}

static void DrivePwm_SetRightDuty(float32 dutyPercent)
{
    uint32 dutyTicks;

    dutyPercent = DrivePwm_LimitDuty(dutyPercent);
    dutyTicks = (uint32)(((float32)MOTOR_PWM_PERIOD_TICKS * dutyPercent) / 100.0f);

    /* Runtime update: write SR1 shadow only. The GTM transfers it to CM1 at
     * the end of the current PWM period, so the period is never cut short.
     * PWM init/start happens once in DrivePwm_Init(). */
    IfxGtm_Tom_Ch_setCompareOneShadow(g_rightPwmDriver.tom,
                                      g_rightPwmDriver.tomChannel,
                                      (uint16)dutyTicks);
    g_rightPwmConfig.dutyCycle = dutyTicks;

    g_rightDutyPercent = dutyPercent;
}

static void DrivePwm_SetForwardDirection(void)
{
    /* LEFT FORWARD = INA 1, INB 0 */
    IfxPort_setPinHigh(LEFT_INA_PORT, LEFT_INA_PIN);
    IfxPort_setPinLow(LEFT_INB_PORT, LEFT_INB_PIN);

    /* RIGHT FORWARD = INA 0, INB 1 */
    IfxPort_setPinLow(RIGHT_INA_PORT, RIGHT_INA_PIN);
    IfxPort_setPinHigh(RIGHT_INB_PORT, RIGHT_INB_PIN);

    g_driveDirectionDebug = (uint8)DriveDirection_Forward;
}

static void DrivePwm_SetReverseDirection(void)
{
    /* LEFT REVERSE = INA 0, INB 1 */
    IfxPort_setPinLow(LEFT_INA_PORT, LEFT_INA_PIN);
    IfxPort_setPinHigh(LEFT_INB_PORT, LEFT_INB_PIN);

    /* RIGHT REVERSE = INA 1, INB 0 */
    IfxPort_setPinHigh(RIGHT_INA_PORT, RIGHT_INA_PIN);
    IfxPort_setPinLow(RIGHT_INB_PORT, RIGHT_INB_PIN);

    g_driveDirectionDebug = (uint8)DriveDirection_Reverse;
}

void DrivePwm_Init(void)
{
    IfxPort_setPinModeOutput(LEFT_INA_PORT, LEFT_INA_PIN,
                             IfxPort_OutputMode_pushPull,
                             IfxPort_OutputIdx_general);
    IfxPort_setPinModeOutput(LEFT_INB_PORT, LEFT_INB_PIN,
                             IfxPort_OutputMode_pushPull,
                             IfxPort_OutputIdx_general);
    IfxPort_setPinModeOutput(RIGHT_INA_PORT, RIGHT_INA_PIN,
                             IfxPort_OutputMode_pushPull,
                             IfxPort_OutputIdx_general);
    IfxPort_setPinModeOutput(RIGHT_INB_PORT, RIGHT_INB_PIN,
                             IfxPort_OutputMode_pushPull,
                             IfxPort_OutputIdx_general);

    IfxPort_setPinLow(LEFT_INA_PORT, LEFT_INA_PIN);
    IfxPort_setPinLow(LEFT_INB_PORT, LEFT_INB_PIN);
    IfxPort_setPinLow(RIGHT_INA_PORT, RIGHT_INA_PIN);
    IfxPort_setPinLow(RIGHT_INB_PORT, RIGHT_INB_PIN);

    IfxGtm_enable(&MODULE_GTM);
    IfxGtm_Cmu_enableClocks(&MODULE_GTM, IFXGTM_CMU_CLKEN_FXCLK);

    IfxGtm_Tom_Pwm_initConfig(&g_leftPwmConfig, &MODULE_GTM);
    g_leftPwmConfig.tom = LEFT_PWM_PIN->tom;
    g_leftPwmConfig.tomChannel = LEFT_PWM_PIN->channel;
    g_leftPwmConfig.clock = IfxGtm_Tom_Ch_ClkSrc_cmuFxclk0;
    g_leftPwmConfig.period = MOTOR_PWM_PERIOD_TICKS;
    g_leftPwmConfig.dutyCycle = 0U;
    g_leftPwmConfig.signalLevel = Ifx_ActiveState_high;
    g_leftPwmConfig.pin.outputPin = LEFT_PWM_PIN;
    g_leftPwmConfig.synchronousUpdateEnabled = TRUE;
    IfxGtm_Tom_Pwm_init(&g_leftPwmDriver, &g_leftPwmConfig);
    IfxGtm_Tom_Pwm_start(&g_leftPwmDriver, TRUE);

    IfxGtm_Tom_Pwm_initConfig(&g_rightPwmConfig, &MODULE_GTM);
    g_rightPwmConfig.tom = RIGHT_PWM_PIN->tom;
    g_rightPwmConfig.tomChannel = RIGHT_PWM_PIN->channel;
    g_rightPwmConfig.clock = IfxGtm_Tom_Ch_ClkSrc_cmuFxclk0;
    g_rightPwmConfig.period = MOTOR_PWM_PERIOD_TICKS;
    g_rightPwmConfig.dutyCycle = 0U;
    g_rightPwmConfig.signalLevel = Ifx_ActiveState_high;
    g_rightPwmConfig.pin.outputPin = RIGHT_PWM_PIN;
    g_rightPwmConfig.synchronousUpdateEnabled = TRUE;
    IfxGtm_Tom_Pwm_init(&g_rightPwmDriver, &g_rightPwmConfig);
    IfxGtm_Tom_Pwm_start(&g_rightPwmDriver, TRUE);

    DrivePwm_Stop();
}

void DrivePwm_SetDuty(float32 leftDutyPercent, float32 rightDutyPercent)
{
    DrivePwm_SetLeftDuty(leftDutyPercent);
    DrivePwm_SetRightDuty(rightDutyPercent);
}

/*
 * NOTE: Forward()/Reverse() change the INA/INB direction pins immediately.
 * Callers must only switch direction while PWM is already 0 and the wheels
 * are (nearly) stopped. Speed_Control enforces this with its direction guard
 * and the reverse-brake ZeroWait state.
 */
void DrivePwm_Forward(float32 dutyPercent)
{
    DrivePwm_SetForwardDirection();
    DrivePwm_SetDuty(dutyPercent, dutyPercent);
    g_motorRunning = (dutyPercent > 0.0f) ? 1U : 0U;
}

void DrivePwm_Reverse(float32 dutyPercent)
{
    DrivePwm_SetReverseDirection();
    DrivePwm_SetDuty(dutyPercent, dutyPercent);
    g_motorRunning = (dutyPercent > 0.0f) ? 1U : 0U;
}

void DrivePwm_Stop(void)
{
    /* Safe order: PWM zero first, then INA/INB = 00. */
    DrivePwm_SetDuty(0.0f, 0.0f);

    IfxPort_setPinLow(LEFT_INA_PORT, LEFT_INA_PIN);
    IfxPort_setPinLow(LEFT_INB_PORT, LEFT_INB_PIN);
    IfxPort_setPinLow(RIGHT_INA_PORT, RIGHT_INA_PIN);
    IfxPort_setPinLow(RIGHT_INB_PORT, RIGHT_INB_PIN);

    g_motorRunning = 0U;
}
