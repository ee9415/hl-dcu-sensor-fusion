#ifndef ENCODER_GPT12_H_
#define ENCODER_GPT12_H_

#include "Ifx_Types.h"

typedef struct
{
    sint32 leftCount;
    sint32 rightCount;
    uint16 leftHwCount;
    uint16 rightHwCount;
} EncoderSnapshot;

void EncoderGpt12_Init(void);
void EncoderGpt12_Service100us(void);
void EncoderGpt12_GetSnapshot(EncoderSnapshot *out);

extern volatile sint32 g_leftEncoderCount;
extern volatile sint32 g_rightEncoderCount;
extern volatile sint32 g_leftEncoderLastHwDelta;
extern volatile sint32 g_rightEncoderLastHwDelta;
extern volatile uint16 g_leftEncoderHwCount;
extern volatile uint16 g_rightEncoderHwCount;
extern volatile uint32 g_leftEncoderEventCount;
extern volatile uint32 g_rightEncoderEventCount;

#endif /* ENCODER_GPT12_H_ */
