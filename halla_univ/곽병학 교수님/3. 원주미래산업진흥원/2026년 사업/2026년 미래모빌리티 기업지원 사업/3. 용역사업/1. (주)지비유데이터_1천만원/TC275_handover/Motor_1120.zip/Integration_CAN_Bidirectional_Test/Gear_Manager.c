#include "Gear_Manager.h"

#include "App_Config.h"

volatile uint8 g_gear = 0U;
volatile uint8 g_driveMode = (uint8)GearDriveMode_Forward;
volatile float32 g_targetRpm = 0.0f;
volatile float32 g_commandedSignedRpm = 0.0f;

static float32 GearManager_RpmFromGear(uint8 gear)
{
    switch (gear)
    {
        case 1U:
            return GEAR_1_RPM;
        case 2U:
            return GEAR_2_RPM;
        case 3U:
            return GEAR_3_RPM;
        case 4U:
            return GEAR_4_RPM;
        case 0U:
        default:
            return GEAR_0_RPM;
    }
}

static void GearManager_RefreshTargets(void)
{
    g_targetRpm = GearManager_RpmFromGear(g_gear);

    if (g_driveMode == (uint8)GearDriveMode_Reverse)
    {
        g_commandedSignedRpm = -g_targetRpm;
    }
    else
    {
        g_commandedSignedRpm = g_targetRpm;
    }
}

void GearManager_Init(void)
{
    g_gear = 0U;
    g_driveMode = (uint8)GearDriveMode_Forward;
    GearManager_RefreshTargets();
}

void GearManager_GearUp(void)
{
    if (g_gear < GEAR_MAX)
    {
        g_gear++;
    }

    GearManager_RefreshTargets();
}

void GearManager_GearDown(void)
{
    if (g_gear > GEAR_MIN)
    {
        g_gear--;
    }

    GearManager_RefreshTargets();
}

void GearManager_Stop(void)
{
    g_gear = 0U;
    GearManager_RefreshTargets();
}

void GearManager_ToggleDriveMode(void)
{
    /* Safety: always enter Gear 0 before changing direction mode. */
    g_gear = 0U;

    if (g_driveMode == (uint8)GearDriveMode_Forward)
    {
        g_driveMode = (uint8)GearDriveMode_Reverse;
    }
    else
    {
        g_driveMode = (uint8)GearDriveMode_Forward;
    }

    GearManager_RefreshTargets();
}

float32 GearManager_GetTargetRpm(void)
{
    return g_targetRpm;
}

float32 GearManager_GetSignedTargetRpm(void)
{
    return g_commandedSignedRpm;
}

GearDriveMode GearManager_GetDriveMode(void)
{
    return (g_driveMode == (uint8)GearDriveMode_Reverse)
            ? GearDriveMode_Reverse
            : GearDriveMode_Forward;
}

uint8 GearManager_GetGear(void)
{
    return g_gear;
}
