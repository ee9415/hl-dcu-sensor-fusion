#include "Speed_Calculate.h"

#include "App_Config.h"
#include "Encoder_GPT12.h"
#include "GPT12_Timer_Interrupt.h"

volatile sint32 g_leftDelta = 0;
volatile sint32 g_rightDelta = 0;
volatile float32 g_leftRpm = 0.0f;
volatile float32 g_rightRpm = 0.0f;
volatile float32 g_vehicleRpmSigned = 0.0f;
volatile uint32 g_speedCalcUpdateCount = 0U;
volatile uint8 g_speedCalcValid = 0U;

static sint32 g_previousLeftCount = 0;
static sint32 g_previousRightCount = 0;
static uint32 g_previousTick100us = 0U;

void SpeedCalc_Init(void)
{
    EncoderSnapshot snapshot;

    EncoderGpt12_GetSnapshot(&snapshot);

    g_previousLeftCount = snapshot.leftCount;
    g_previousRightCount = snapshot.rightCount;
    g_previousTick100us = g_tick100us;

    g_leftDelta = 0;
    g_rightDelta = 0;
    g_leftRpm = 0.0f;
    g_rightRpm = 0.0f;
    g_vehicleRpmSigned = 0.0f;
    g_speedCalcUpdateCount = 0U;
    g_speedCalcValid = 0U;
}

void SpeedCalc_Update100ms(void)
{
    EncoderSnapshot snapshot;
    uint32 currentTick;
    uint32 deltaTick;
    float32 dtSec;

    EncoderGpt12_GetSnapshot(&snapshot);
    currentTick = g_tick100us;
    deltaTick = (uint32)(currentTick - g_previousTick100us);

    if (deltaTick == 0U)
    {
        return;
    }

    g_leftDelta = snapshot.leftCount - g_previousLeftCount;
    g_rightDelta = snapshot.rightCount - g_previousRightCount;

    dtSec = ((float32)deltaTick) * 0.0001f;

    if (dtSec > 0.0f)
    {
        g_leftRpm = ((float32)g_leftDelta * 60.0f) / (COUNTS_PER_REV * dtSec);
        g_rightRpm = ((float32)g_rightDelta * 60.0f) / (COUNTS_PER_REV * dtSec);
        g_vehicleRpmSigned = 0.5f * (g_leftRpm + g_rightRpm);
        g_speedCalcValid = 1U;
    }

    g_previousLeftCount = snapshot.leftCount;
    g_previousRightCount = snapshot.rightCount;
    g_previousTick100us = currentTick;
    g_speedCalcUpdateCount++;
}

SpeedValue SpeedCalc_Get(void)
{
    EncoderSnapshot snapshot;
    SpeedValue value;

    EncoderGpt12_GetSnapshot(&snapshot);

    value.leftCount = snapshot.leftCount;
    value.rightCount = snapshot.rightCount;
    value.leftDelta = g_leftDelta;
    value.rightDelta = g_rightDelta;
    value.leftRpm = g_leftRpm;
    value.rightRpm = g_rightRpm;
    value.vehicleRpmSigned = g_vehicleRpmSigned;
    value.valid = (g_speedCalcValid != 0U) ? TRUE : FALSE;

    return value;
}
