#ifndef PS2_CONTROLLER_H_
#define PS2_CONTROLLER_H_

#include "Ifx_Types.h"


void Ps2Controller_Init(void);
void Ps2Controller_Poll20ms(void);

boolean Ps2Controller_IsConnected(void);
uint16 Ps2Controller_GetButtons(void);

/* Analog steering */
boolean Ps2Controller_IsSteeringAnalogActive(void);
uint8 Ps2Controller_GetSteeringRaw(void);


/* Raw packet debug */
extern volatile uint8 g_ps2Raw0;
extern volatile uint8 g_ps2Raw1;
extern volatile uint8 g_ps2Raw2;
extern volatile uint8 g_ps2Raw3;
extern volatile uint8 g_ps2Raw4;
extern volatile uint8 g_ps2Raw5;
extern volatile uint8 g_ps2Raw6;
extern volatile uint8 g_ps2Raw7;
extern volatile uint8 g_ps2Raw8;


/* PS2 connection / mode */
extern volatile uint8 g_ps2ReceiverAlive;
extern volatile uint8 g_ps2PadConnected;
extern volatile uint8 g_ps2Mode;
extern volatile uint8 g_ps2Status;


/* Buttons */
extern volatile uint16 g_ps2Buttons;


/* Analog sticks */
extern volatile uint8 g_ps2Rx;
extern volatile uint8 g_ps2Ry;
extern volatile uint8 g_ps2Lx;
extern volatile uint8 g_ps2Ly;


/* Poll debug */
extern volatile uint32 g_ps2PollCount;
extern volatile uint32 g_ps2OkCount;
extern volatile uint32 g_ps2ErrCount;
extern volatile uint8 g_ps2LossCount;


/* Steering debug */
extern volatile uint8 g_ps2SteeringRaw;
extern volatile uint8 g_ps2SteeringAnalogActive;


#endif /* PS2_CONTROLLER_H_ */
