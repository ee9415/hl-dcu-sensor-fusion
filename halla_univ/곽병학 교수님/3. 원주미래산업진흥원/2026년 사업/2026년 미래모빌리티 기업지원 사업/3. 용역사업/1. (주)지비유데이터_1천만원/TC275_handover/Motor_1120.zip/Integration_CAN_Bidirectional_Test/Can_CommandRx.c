#include "Can_CommandRx.h"

#include "IfxMultican_Can.h"
#include "IfxPort.h"
#include "Speed_Calculate.h"
#include "Steering_ADC.h"
#include "Steering_PWM.h"
#include "Can_VehicleControl.h"
#include "Drive_PWM.h"
#include "Speed_Control.h"
#include "Safety_Config.h"

/* TEST ONLY: 0x200 Standard CAN 2.0, DLC=8, 500 kbit/s.
 * Byte 0-1: signed RPM, LE; byte 2-3: signed steer deg, LE.
 * Byte 4: Enable; byte 5: Stop mode; byte 6-7: reserved.
 * No integration with motor, steering or joystick control in this version.
 */
#define CAN_COMMAND_ID          (0x200U)
#define CAN_COMMAND_RX_OBJ_ID   (3U)

static IfxMultican_Can g_canModule;
static IfxMultican_Can_Node g_canNode;
static IfxMultican_Can_MsgObj g_canRxObj;
static IfxMultican_Can_MsgObj g_canSteerTxObj;
static IfxMultican_Can_MsgObj g_canRpmTxObj;
static IfxMultican_Can_MsgObj g_canCtrlTxObj;
volatile uint32 g_canTxCtrlCount = 0U;
volatile uint32 g_canTxInitCtrlStatus = 0U;
volatile uint32 g_canTxSteerCount = 0U;
volatile uint32 g_canTxRpmCount = 0U;
volatile uint32 g_canTxBusyCount = 0U;
volatile uint32 g_canTxOtherErrorCount = 0U;
volatile uint32 g_canTxInitSteerStatus = 0U;
volatile uint32 g_canTxInitRpmStatus = 0U;
static uint8 s_txDivider = 0U;

static sint16 CanTx_EncodeRpm(float32 value)
{
    if (value > 32767.0f) value = 32767.0f;
    if (value < -32768.0f) value = -32768.0f;
    return (sint16)value;
}

static sint8 CanTx_EncodeInt8(float32 value)
{
    if (value > 127.0f) value = 127.0f;
    if (value < -128.0f) value = -128.0f;
    return (sint8)((value >= 0.0f) ? (value + 0.5f) : (value - 0.5f));
}

static uint32 CanTx_PackPair(sint16 a, sint16 b)
{
    return (uint32)(uint16)a | ((uint32)(uint16)b << 16U);
}

static void CanTx_Send(IfxMultican_Can_MsgObj *obj, uint32 id,
                       uint32 lo, uint32 hi, volatile uint32 *count)
{
    IfxMultican_Message msg;
    IfxMultican_Status result;
    IfxMultican_Message_init(&msg, id, lo, hi, IfxMultican_DataLengthCode_8);
    result = IfxMultican_Can_MsgObj_sendMessage(obj, &msg);
    if (result == IfxMultican_Status_ok)
    {
        (*count)++;
    }
    else if (result == IfxMultican_Status_notSentBusy)
    {
        g_canTxBusyCount++;
    }
    else
    {
        g_canTxOtherErrorCount++;
    }
}


volatile sint16 g_canRxTargetRpm = 0;
volatile sint16 g_canRxTargetSteerDeg = 0;
volatile uint8  g_canRxEnable = 0U;
volatile uint8  g_canRxStopMode = 0U;
volatile uint32 g_canRxCount = 0U;
volatile uint32 g_canRxErrorCount = 0U;
volatile uint32 g_canRxInitModuleStatus = 0U;
volatile uint32 g_canRxInitNodeStatus = 0U;
volatile uint32 g_canRxInitMsgObjStatus = 0U;
volatile uint8  g_canRxValid = 0U;

/* 0x200 integrity (see Safety_Config.h) */
volatile uint8  g_canRxAliveCounter = 0U;
volatile uint8  g_canRxChecksum = 0U;
volatile uint32 g_canRxChecksumErrorCount = 0U;
volatile uint32 g_canRxAliveErrorCount = 0U;
volatile uint32 g_canRxAliveGapCount = 0U;
static uint8 s_rxLastAlive = 0U;
static uint8 s_rxAliveValid = 0U;

/* Bus-off recovery (see Safety_Config.h) */
volatile uint8  g_canBusOff = 0U;            /* 1 while the node is bus-off   */
volatile uint32 g_canBusOffCount = 0U;       /* bus-off events since boot     */
volatile uint32 g_canBusOffRecoveryCount = 0U;
volatile uint8  g_canBusOffLocked = 0U;      /* 1 = gave up, reset required   */
volatile uint8  g_canTxErrorCounter = 0U;    /* TEC, live                     */
volatile uint8  g_canRxErrorCounter = 0U;    /* REC, live                     */
static uint32 s_busOffElapsedMs = 0U;
static uint32 s_recoveryTimeMs[CAN_BUSOFF_MAX_RECOVERIES];
static uint8  s_recoveryIndex = 0U;
static uint32 s_monitorTimeMs = 0U;

void CanCommandRx_Init(void)
{
    IfxMultican_Can_Config moduleConfig;
    IfxMultican_Can_NodeConfig nodeConfig;
    IfxMultican_Can_MsgObjConfig msgConfig;

    /* Friend project uses P20.6 to enable an external transceiver
     * (active-low STB). Verify your hardware transceiver before using. */
    IfxPort_setPinModeOutput(&MODULE_P20, 6U,
                             IfxPort_OutputMode_pushPull,
                             IfxPort_OutputIdx_general);
    IfxPort_setPinLow(&MODULE_P20, 6U);

    IfxMultican_Can_initModuleConfig(&moduleConfig, &MODULE_CAN);
    g_canRxInitModuleStatus = (uint32)IfxMultican_Can_initModule(&g_canModule, &moduleConfig);

    IfxMultican_Can_Node_initConfig(&nodeConfig, &g_canModule);
    nodeConfig.nodeId = IfxMultican_NodeId_0;
    nodeConfig.baudrate = 500000U;
    nodeConfig.rxPin = &IfxMultican_RXD0B_P20_7_IN;
    nodeConfig.rxPinMode = IfxPort_InputMode_pullUp;
    nodeConfig.txPin = &IfxMultican_TXD0_P20_8_OUT;
    nodeConfig.txPinMode = IfxPort_OutputMode_pushPull;
    nodeConfig.pinDriver = IfxPort_PadDriver_cmosAutomotiveSpeed1;
    g_canRxInitNodeStatus = (uint32)IfxMultican_Can_Node_init(&g_canNode, &nodeConfig);

    IfxMultican_Can_MsgObj_initConfig(&msgConfig, &g_canNode);
    msgConfig.msgObjId = CAN_COMMAND_RX_OBJ_ID;
    msgConfig.messageId = CAN_COMMAND_ID;
    msgConfig.acceptanceMask = 0x7FFU;
    msgConfig.frame = IfxMultican_Frame_receive;
    msgConfig.control.messageLen = IfxMultican_DataLengthCode_8;
    msgConfig.control.extendedFrame = FALSE;
    msgConfig.control.matchingId = TRUE;
    g_canRxInitMsgObjStatus = (uint32)IfxMultican_Can_MsgObj_init(&g_canRxObj, &msgConfig);

    /* TX uses the same CAN node and transceiver as the verified RX channel. */
    IfxMultican_Can_MsgObj_initConfig(&msgConfig, &g_canNode);
    msgConfig.msgObjId = 4U;
    msgConfig.messageId = 0x101U;
    msgConfig.frame = IfxMultican_Frame_transmit;
    msgConfig.control.messageLen = IfxMultican_DataLengthCode_8;
    msgConfig.control.extendedFrame = FALSE;
    g_canTxInitSteerStatus = (uint32)IfxMultican_Can_MsgObj_init(&g_canSteerTxObj, &msgConfig);

    IfxMultican_Can_MsgObj_initConfig(&msgConfig, &g_canNode);
    msgConfig.msgObjId = 5U;
    msgConfig.messageId = 0x102U;
    msgConfig.frame = IfxMultican_Frame_transmit;
    msgConfig.control.messageLen = IfxMultican_DataLengthCode_8;
    msgConfig.control.extendedFrame = FALSE;
    g_canTxInitRpmStatus = (uint32)IfxMultican_Can_MsgObj_init(&g_canRpmTxObj, &msgConfig);

    /* 0x103: live control monitor (target / duty / integral), see PollTx5ms. */
    IfxMultican_Can_MsgObj_initConfig(&msgConfig, &g_canNode);
    msgConfig.msgObjId = 6U;
    msgConfig.messageId = 0x103U;
    msgConfig.frame = IfxMultican_Frame_transmit;
    msgConfig.control.messageLen = IfxMultican_DataLengthCode_8;
    msgConfig.control.extendedFrame = FALSE;
    g_canTxInitCtrlStatus = (uint32)IfxMultican_Can_MsgObj_init(&g_canCtrlTxObj, &msgConfig);
}

void CanCommandRx_Poll(void)
{
    IfxMultican_Message msg;
    IfxMultican_Status status;
    uint8 data[8];
    uint8 i;

    /* Only read a pending message to avoid unnecessary status clearing. */
    if (IfxMultican_Can_MsgObj_isRxPending(&g_canRxObj) == FALSE)
    {
        return;
    }

    IfxMultican_Message_init(&msg, CAN_COMMAND_ID, 0U, 0U, IfxMultican_DataLengthCode_8);
    status = IfxMultican_Can_MsgObj_readMessage(&g_canRxObj, &msg);

    if ((status & IfxMultican_Status_newData) == 0U)
    {
        g_canRxErrorCount++;
        return;
    }
    if ((msg.id != CAN_COMMAND_ID) || (msg.lengthCode != IfxMultican_DataLengthCode_8))
    {
        g_canRxErrorCount++;
        return;
    }

    for (i = 0U; i < 4U; ++i)
    {
        data[i] = (uint8)(msg.data[0] >> (8U * i));
        data[i + 4U] = (uint8)(msg.data[1] >> (8U * i));
    }

    /* Raw integrity bytes are always visible for debugging. */
    g_canRxAliveCounter = data[6];
    g_canRxChecksum = data[7];

#if (CAN_RX_INTEGRITY_CHECK_ENABLE != 0U)
    {
        uint8 sum = 0U;

        for (i = 0U; i < 7U; ++i)
        {
            sum ^= data[i];
        }

        if (sum != data[7])
        {
            g_canRxChecksumErrorCount++;
            return;   /* discard: not counted as a fresh command */
        }

        if ((s_rxAliveValid != 0U) && (data[6] == s_rxLastAlive))
        {
            /* Same counter again: sender is repeating a stale frame. */
            g_canRxAliveErrorCount++;
            return;
        }

        if ((s_rxAliveValid != 0U) && (data[6] != (uint8)(s_rxLastAlive + 1U)))
        {
            /* Frames were lost in between; still accepted. */
            g_canRxAliveGapCount++;
        }

        s_rxLastAlive = data[6];
        s_rxAliveValid = 1U;
    }
#endif

    g_canRxTargetRpm = (sint16)((uint16)data[0] | ((uint16)data[1] << 8U));
    g_canRxTargetSteerDeg = (sint16)((uint16)data[2] | ((uint16)data[3] << 8U));
    g_canRxEnable = data[4];
    g_canRxStopMode = data[5];
    g_canRxCount++;
    g_canRxValid = 1U;
}

/* Call every 5ms; transmit 0x101 and 0x102 once per 100ms.
 * 0x101 byte0-1: requested steer degrees int16 LE (from existing control target),
 *       byte2-3: raw potentiometer ADC uint16 LE,
 *       byte4: ADC valid, byte5: control mode (0 manual,1 auto,2 fault),
 *       byte6-7 reserved.
 * IMPORTANT: ADC counts are NOT calibrated actual steering degrees.
 * 0x102 byte0-1: actual left RPM int16 LE,
 *       byte2-3: actual right RPM int16 LE,
 *       byte4-5: signed vehicle RPM int16 LE,
 *       byte6: RPM feedback valid, byte7: control mode.
 */
void CanCommandRx_PollTx5ms(void)
{
    uint16 raw;
    uint32 low;
    uint32 high;
    if (++s_txDivider < 20U) return;
    s_txDivider = 0U;

    raw = (g_potRaw > 65535U) ? 65535U : (uint16)g_potRaw;
    low = CanTx_PackPair((sint16)g_targetSteeringDeg, (sint16)raw);
    high = (uint32)g_potValid | ((uint32)g_canControlMode << 8U);
    CanTx_Send(&g_canSteerTxObj, 0x101U, low, high, &g_canTxSteerCount);

    low = CanTx_PackPair(CanTx_EncodeRpm(g_leftRpm), CanTx_EncodeRpm(g_rightRpm));
    high = CanTx_PackPair(CanTx_EncodeRpm(g_vehicleRpmSigned),
                           (sint16)((uint16)g_speedCalcValid | ((uint16)g_canControlMode << 8U)));
    CanTx_Send(&g_canRpmTxObj, 0x102U, low, high, &g_canTxRpmCount);

    /* 0x103 live control monitor, every 100 ms:
     * byte0-1: ramped target RPM x10, int16 LE   (e.g. 650 = 65.0 RPM)
     * byte2-3: left duty %  x10, int16 LE        (e.g. 284 = 28.4 %)
     * byte4-5: right duty % x10, int16 LE
     * byte6  : left PI integral,  int8 (limit +-50)
     * byte7  : right PI integral, int8 (limit +-50)
     */
    low = CanTx_PackPair(CanTx_EncodeRpm(g_rampedTargetRpm * 10.0f),
                         CanTx_EncodeRpm(g_leftDutyPercent * 10.0f));
    high = (uint32)(uint16)CanTx_EncodeRpm(g_rightDutyPercent * 10.0f) |
           ((uint32)(uint8)CanTx_EncodeInt8(g_leftIntegral) << 16U) |
           ((uint32)(uint8)CanTx_EncodeInt8(g_rightIntegral) << 24U);
    CanTx_Send(&g_canCtrlTxObj, 0x103U, low, high, &g_canTxCtrlCount);
}


/*
 * CAN bus-off monitor + recovery. Call every 5 ms.
 *
 * Bus-off: the MultiCAN node sets INIT itself and leaves the bus.
 *  - AUTO / STOPPING : latch FAULT immediately (motor stop, SELECT to recover).
 *  - MANUAL          : joystick driving does not need CAN, no motor action.
 *  - After CAN_BUSOFF_RECOVERY_DELAY_MS the node is re-enabled (INIT = 0);
 *    the hardware then waits for 128 x 11 recessive bits before rejoining.
 *  - More than CAN_BUSOFF_MAX_RECOVERIES recoveries within
 *    CAN_BUSOFF_WINDOW_MS -> stop recovering (g_canBusOffLocked = 1).
 * Recovery never restarts driving: FAULT stays latched until SELECT.
 */
void CanCommandRx_BusOffMonitor5ms(void)
{
    Ifx_CAN_N *node = g_canNode.node;
    uint8 busOff;
    uint8 i;
    uint8 recent;

    s_monitorTimeMs += 5U;

    g_canTxErrorCounter = (uint8)node->ECNT.B.TEC;
    g_canRxErrorCounter = (uint8)node->ECNT.B.REC;

    busOff = (uint8)node->SR.B.BOFF;

    if (busOff == 0U)
    {
        g_canBusOff = 0U;
        s_busOffElapsedMs = 0U;
        return;
    }

    if (g_canBusOff == 0U)
    {
        /* New bus-off event. */
        g_canBusOff = 1U;
        g_canBusOffCount++;
        s_busOffElapsedMs = 0U;

        if (g_canControlMode != 0U)   /* not MANUAL */
        {
            CanVehicleControl_EmergencyStop();
        }
    }

    if (g_canBusOffLocked != 0U)
    {
        return;
    }

    if (s_busOffElapsedMs < CAN_BUSOFF_RECOVERY_DELAY_MS)
    {
        s_busOffElapsedMs += 5U;
        return;
    }

    if (node->CR.B.INIT == 0U)
    {
        /* Recovery already requested; hardware is waiting for bus idle. */
        return;
    }

    /* Count recoveries inside the window. */
    recent = 0U;
    for (i = 0U; i < CAN_BUSOFF_MAX_RECOVERIES; ++i)
    {
        if ((s_recoveryTimeMs[i] != 0U) &&
            ((s_monitorTimeMs - s_recoveryTimeMs[i]) < CAN_BUSOFF_WINDOW_MS))
        {
            recent++;
        }
    }

    if (recent >= CAN_BUSOFF_MAX_RECOVERIES)
    {
        g_canBusOffLocked = 1U;
        return;
    }

    s_recoveryTimeMs[s_recoveryIndex] = s_monitorTimeMs;
    s_recoveryIndex = (uint8)((s_recoveryIndex + 1U) % CAN_BUSOFF_MAX_RECOVERIES);

    g_canBusOffRecoveryCount++;
    IfxMultican_Node_activate(node);   /* INIT = 0 */
}

