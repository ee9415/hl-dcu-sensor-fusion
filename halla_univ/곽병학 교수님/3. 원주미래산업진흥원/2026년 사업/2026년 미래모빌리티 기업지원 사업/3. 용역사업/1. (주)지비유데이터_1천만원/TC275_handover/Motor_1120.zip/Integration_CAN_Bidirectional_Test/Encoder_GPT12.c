#include "Encoder_GPT12.h"

#include "App_Config.h"
#include "Board_Pins.h"
#include "IfxCpu.h"
#include "IfxGpt12.h"
#include "IfxPort.h"

volatile sint32 g_leftEncoderCount = 0;
volatile sint32 g_rightEncoderCount = 0;
volatile sint32 g_leftEncoderLastHwDelta = 0;
volatile sint32 g_rightEncoderLastHwDelta = 0;
volatile uint16 g_leftEncoderHwCount = 0U;
volatile uint16 g_rightEncoderHwCount = 0U;
volatile uint32 g_leftEncoderEventCount = 0U;
volatile uint32 g_rightEncoderEventCount = 0U;

static uint16 g_prevLeftHwCount = 0U;
static uint16 g_prevRightHwCount = 0U;

static sint32 Encoder_Compute16BitDelta(uint16 previousCount, uint16 currentCount)
{
    return (sint32)((sint16)(currentCount - previousCount));
}

void EncoderGpt12_Init(void)
{
    IfxGpt12_enableModule(&MODULE_GPT120);
    IfxGpt12_setGpt1BlockPrescaler(&MODULE_GPT120, IfxGpt12_Gpt1BlockPrescaler_4);

    IfxGpt12_T3_run(&MODULE_GPT120, IfxGpt12_TimerRun_stop);
    IfxGpt12_T2_run(&MODULE_GPT120, IfxGpt12_TimerRun_stop);

    /* LEFT: P02.6 = T3INA, P02.7 = T3EUDA */
    IfxGpt12_initTxInPinWithPadLevel(&IfxGpt120_T3INA_P02_6_IN,
                                     IfxPort_InputMode_pullUp,
                                     IfxPort_PadDriver_cmosAutomotiveSpeed1);
    IfxGpt12_initTxEudInPinWithPadLevel(&IfxGpt120_T3EUDA_P02_7_IN,
                                        IfxPort_InputMode_pullUp,
                                        IfxPort_PadDriver_cmosAutomotiveSpeed1);

    /* RIGHT: P00.7 = T2INA, P00.8 = T2EUDA */
    IfxGpt12_initTxInPinWithPadLevel(&IfxGpt120_T2INA_P00_7_IN,
                                     IfxPort_InputMode_pullUp,
                                     IfxPort_PadDriver_cmosAutomotiveSpeed1);
    IfxGpt12_initTxEudInPinWithPadLevel(&IfxGpt120_T2EUDA_P00_8_IN,
                                        IfxPort_InputMode_pullUp,
                                        IfxPort_PadDriver_cmosAutomotiveSpeed1);

    IfxGpt12_T3_setTimerValue(&MODULE_GPT120, 0U);
    IfxGpt12_T3_setMode(&MODULE_GPT120, IfxGpt12_Mode_incrementalInterfaceEdgeDetection);
    IfxGpt12_T3_setIncrementalInterfaceInputMode(&MODULE_GPT120,
                                                  IfxGpt12_IncrementalInterfaceInputMode_bothEdgesTxINOrTxEUD);
    IfxGpt12_T3_setDirectionSource(&MODULE_GPT120, IfxGpt12_TimerDirectionSource_external);
    IfxGpt12_T3_setTimerDirection(&MODULE_GPT120, IfxGpt12_TimerDirection_up);

    IfxGpt12_T2_setTimerValue(&MODULE_GPT120, 0U);
    IfxGpt12_T2_setMode(&MODULE_GPT120, IfxGpt12_Mode_incrementalInterfaceEdgeDetection);
    IfxGpt12_T2_setIncrementalInterfaceInputMode(&MODULE_GPT120,
                                                  IfxGpt12_IncrementalInterfaceInputMode_bothEdgesTxINOrTxEUD);
    IfxGpt12_T2_setDirectionSource(&MODULE_GPT120, IfxGpt12_TimerDirectionSource_external);
    IfxGpt12_T2_setTimerDirection(&MODULE_GPT120, IfxGpt12_TimerDirection_up);

    IfxGpt12_T3_run(&MODULE_GPT120, IfxGpt12_TimerRun_start);
    IfxGpt12_T2_run(&MODULE_GPT120, IfxGpt12_TimerRun_start);

    g_prevLeftHwCount = IfxGpt12_T3_getTimerValue(&MODULE_GPT120);
    g_prevRightHwCount = IfxGpt12_T2_getTimerValue(&MODULE_GPT120);

    g_leftEncoderCount = 0;
    g_rightEncoderCount = 0;
    g_leftEncoderLastHwDelta = 0;
    g_rightEncoderLastHwDelta = 0;
    g_leftEncoderHwCount = g_prevLeftHwCount;
    g_rightEncoderHwCount = g_prevRightHwCount;
    g_leftEncoderEventCount = 0U;
    g_rightEncoderEventCount = 0U;
}

void EncoderGpt12_Service100us(void)
{
    uint16 leftHwCount;
    uint16 rightHwCount;
    sint32 leftDelta;
    sint32 rightDelta;

    leftHwCount = IfxGpt12_T3_getTimerValue(&MODULE_GPT120);
    rightHwCount = IfxGpt12_T2_getTimerValue(&MODULE_GPT120);

    leftDelta = Encoder_Compute16BitDelta(g_prevLeftHwCount, leftHwCount);
    rightDelta = Encoder_Compute16BitDelta(g_prevRightHwCount, rightHwCount);

    g_prevLeftHwCount = leftHwCount;
    g_prevRightHwCount = rightHwCount;

    g_leftEncoderHwCount = leftHwCount;
    g_rightEncoderHwCount = rightHwCount;
    g_leftEncoderLastHwDelta = leftDelta;
    g_rightEncoderLastHwDelta = rightDelta;

    if (leftDelta != 0)
    {
        g_leftEncoderCount += leftDelta * (sint32)LEFT_ENCODER_COUNT_SIGN;
        g_leftEncoderEventCount += (uint32)((leftDelta < 0) ? -leftDelta : leftDelta);
    }

    if (rightDelta != 0)
    {
        g_rightEncoderCount += rightDelta * (sint32)RIGHT_ENCODER_COUNT_SIGN;
        g_rightEncoderEventCount += (uint32)((rightDelta < 0) ? -rightDelta : rightDelta);
    }
}

void EncoderGpt12_GetSnapshot(EncoderSnapshot *out)
{
    boolean interruptState;

    if (out == 0)
    {
        return;
    }

    interruptState = IfxCpu_disableInterrupts();
    out->leftCount = g_leftEncoderCount;
    out->rightCount = g_rightEncoderCount;
    out->leftHwCount = g_leftEncoderHwCount;
    out->rightHwCount = g_rightEncoderHwCount;
    IfxCpu_restoreInterrupts(interruptState);
}
