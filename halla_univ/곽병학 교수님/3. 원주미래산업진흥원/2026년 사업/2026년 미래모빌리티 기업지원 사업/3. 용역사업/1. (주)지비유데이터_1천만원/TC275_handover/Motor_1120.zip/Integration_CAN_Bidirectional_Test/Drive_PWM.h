#ifndef DRIVE_PWM_H_
#define DRIVE_PWM_H_

#include "Ifx_Types.h"

typedef enum
{
    DriveDirection_Forward = 0,
    DriveDirection_Reverse = 1
} DriveDirection;

void DrivePwm_Init(void);
void DrivePwm_Forward(float32 dutyPercent);
void DrivePwm_Reverse(float32 dutyPercent);
void DrivePwm_Stop(void);
void DrivePwm_SetDuty(float32 leftDutyPercent, float32 rightDutyPercent);

extern volatile float32 g_leftDutyPercent;
extern volatile float32 g_rightDutyPercent;
extern volatile uint8 g_driveDirectionDebug;
extern volatile uint8 g_motorRunning;

#endif /* DRIVE_PWM_H_ */
