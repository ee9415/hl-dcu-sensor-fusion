#ifndef CAN_VEHICLECONTROL_H_
#define CAN_VEHICLECONTROL_H_
#include "Ifx_Types.h"
#include "Gear_Manager.h"
void CanVehicleControl_Init(void);
void CanVehicleControl_Update5ms(void);
void CanVehicleControl_SelectManual(void);
void CanVehicleControl_EmergencyStop(void);
void CanVehicleControl_SelectAuto(void);
uint8 CanVehicleControl_IsAuto(void);
uint8 CanVehicleControl_IsFault(void);
extern volatile uint8 g_canControlMode; /* 0 MANUAL, 1 AUTO, 2 FAULT */
extern volatile uint32 g_canModeRejectedCount;
float32 CanVehicleControl_GetTargetRpm(void);
float32 CanVehicleControl_GetSignedTargetRpm(void);
GearDriveMode CanVehicleControl_GetDriveMode(void);
extern volatile uint8 g_canCommandFresh;
extern volatile uint8 g_canCommandArmed;
extern volatile uint32 g_canCommandAgeMs;
extern volatile uint8 g_canCommandRejected;
#endif
