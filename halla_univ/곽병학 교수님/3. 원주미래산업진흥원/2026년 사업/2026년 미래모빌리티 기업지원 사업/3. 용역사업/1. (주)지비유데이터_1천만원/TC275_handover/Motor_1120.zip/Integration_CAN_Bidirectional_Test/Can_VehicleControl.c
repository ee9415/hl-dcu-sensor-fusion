#include "Can_VehicleControl.h"

#include "App_Config.h"

#include "Can_CommandRx.h"

#include "Gear_Manager.h"

#include "Speed_Control.h"

#include "Steering_PWM.h"

#include "Speed_Calculate.h"

/* Mode: 0=MANUAL, 1=AUTO, 2=FAULT, 3=STOPPING. */

#define CAN_MODE_MANUAL                 (0U)

#define CAN_MODE_AUTO                   (1U)

#define CAN_MODE_FAULT                  (2U)

#define CAN_MODE_STOPPING               (3U)

/* ControlLoop invokes CanVehicleControl_Update5ms() every 5 ms. */

#define CAN_STOP_STABLE_TICKS_5MS       (20U)   /* 100 ms */

#define CAN_STOP_TIMEOUT_TICKS_5MS      (600U)  /* 3000 ms */

volatile uint8 g_canCommandFresh = 0U;

volatile uint8 g_canCommandArmed = 0U;

volatile uint32 g_canCommandAgeMs = CAN_COMMAND_TIMEOUT_MS;

volatile uint8 g_canCommandRejected = 0U;

volatile uint8 g_canControlMode = CAN_MODE_MANUAL;

volatile uint32 g_canModeRejectedCount = 0U;

/* Optional debug observability, inspect in ADS Expressions. */

volatile uint32 g_canStopElapsedMs = 0U;

volatile uint32 g_canStopStableMs = 0U;

volatile uint8 g_canStopTimedOut = 0U;

static uint32 s_lastRxCount = 0U;

static float32 s_targetSignedRpm = 0.0f;

static GearDriveMode s_driveMode = GearDriveMode_Forward;

static uint16 s_stopElapsedTicks = 0U;

static uint8 s_stopStableTicks = 0U;

static uint8 CanVehicleControl_Stopped(void)

{

    if (g_speedCalcValid == 0U)

    {

        return 0U;

    }

    if ((g_leftRpm > MODE_SWITCH_MAX_RPM) ||

        (g_leftRpm < -MODE_SWITCH_MAX_RPM) ||

        (g_rightRpm > MODE_SWITCH_MAX_RPM) ||

        (g_rightRpm < -MODE_SWITCH_MAX_RPM))

    {

        return 0U;

    }

    return 1U;

}

static void CanVehicleControl_CommandStop(void)

{

    g_canCommandArmed = 0U;

    g_canCommandFresh = 0U;

    s_targetSignedRpm = 0.0f;

    GearManager_Stop();

    SpeedControl_StopNow();

    SteeringPwm_SetTargetAngle(0.0f);

}

void CanVehicleControl_Init(void)

{

    g_canControlMode = CAN_MODE_MANUAL;

    g_canModeRejectedCount = 0U;

    s_lastRxCount = g_canRxCount;

    s_targetSignedRpm = 0.0f;

    s_driveMode = GearDriveMode_Forward;

    g_canCommandAgeMs = CAN_COMMAND_TIMEOUT_MS;

    g_canCommandFresh = 0U;

    g_canCommandArmed = 0U;

    g_canCommandRejected = 0U;

    s_stopElapsedTicks = 0U;

    s_stopStableTicks = 0U;

    g_canStopElapsedMs = 0U;

    g_canStopStableMs = 0U;

    g_canStopTimedOut = 0U;

}

uint8 CanVehicleControl_IsAuto(void)

{

    return (g_canControlMode == CAN_MODE_AUTO) ? 1U : 0U;

}

uint8 CanVehicleControl_IsFault(void)

{

    return (g_canControlMode == CAN_MODE_FAULT) ? 1U : 0U;

}

void CanVehicleControl_SelectAuto(void)

{

    if (g_canControlMode != CAN_MODE_MANUAL)

    {

        return;

    }

    if (CanVehicleControl_Stopped() == 0U)

    {

        g_canModeRejectedCount++;

        return;

    }

    CanVehicleControl_CommandStop();

    s_lastRxCount = g_canRxCount;

    s_driveMode = GearDriveMode_Forward;

    g_canCommandAgeMs = 0U;

    g_canCommandRejected = 0U;

    g_canStopTimedOut = 0U;

    s_stopElapsedTicks = 0U;

    s_stopStableTicks = 0U;

    g_canStopElapsedMs = 0U;

    g_canStopStableMs = 0U;

    g_canControlMode = CAN_MODE_AUTO;

}

void CanVehicleControl_EmergencyStop(void)

{

    g_canControlMode = CAN_MODE_FAULT;

    CanVehicleControl_CommandStop();

}

void CanVehicleControl_SelectManual(void)

{

    uint8 wasAuto;

    float32 previousTarget;

    if ((g_canControlMode == CAN_MODE_MANUAL) ||

        (g_canControlMode == CAN_MODE_STOPPING))

    {

        return;

    }

    wasAuto = (g_canControlMode == CAN_MODE_AUTO) ? 1U : 0U;

    previousTarget = s_targetSignedRpm;

    /* Block all incoming drive commands before requesting deceleration. */

    g_canControlMode = CAN_MODE_STOPPING;

    s_stopElapsedTicks = 0U;

    s_stopStableTicks = 0U;

    g_canStopElapsedMs = 0U;

    g_canStopStableMs = 0U;

    g_canStopTimedOut = 0U;

    s_lastRxCount = g_canRxCount;

    g_canCommandArmed = 0U;

    g_canCommandFresh = 0U;

    s_targetSignedRpm = 0.0f;

    SteeringPwm_SetTargetAngle(0.0f);

    /* AUTO normal stop: retain PWM and initiate exactly one speed ramp.

     * A FAULT-to-MANUAL recovery must never re-enable motor drive. */

    if ((wasAuto != 0U) &&

        ((previousTarget > 0.0f) || (previousTarget < 0.0f)))

    {

        SpeedControl_RequestCanRampStop();

    }

    else

    {

        GearManager_Stop();

        SpeedControl_StopNow();

    }

}

void CanVehicleControl_Update5ms(void)

{

    if (g_canControlMode == CAN_MODE_STOPPING)

    {

        /* Ignore all CAN drive commands; do not cancel a running ramp. */

        s_lastRxCount = g_canRxCount;

        g_canCommandArmed = 0U;

        g_canCommandFresh = 0U;

        s_targetSignedRpm = 0.0f;

        if (s_stopElapsedTicks < CAN_STOP_TIMEOUT_TICKS_5MS)

        {

            s_stopElapsedTicks++;

        }

        g_canStopElapsedMs = (uint32)s_stopElapsedTicks * 5U;

        /* Wait for the speed-control ramp to finish before accepting

         * stationary encoder readings as permission to enter MANUAL. */

        if ((g_stopRampActive == 0U) &&

            (CanVehicleControl_Stopped() != 0U))

        {

            if (s_stopStableTicks < CAN_STOP_STABLE_TICKS_5MS)

            {

                s_stopStableTicks++;

            }

        }

        else

        {

            s_stopStableTicks = 0U;

        }

        g_canStopStableMs = (uint32)s_stopStableTicks * 5U;

        if (s_stopStableTicks >= CAN_STOP_STABLE_TICKS_5MS)

        {

            s_lastRxCount = g_canRxCount;

            CanVehicleControl_CommandStop();

            g_canControlMode = CAN_MODE_MANUAL;

        }

        else if (s_stopElapsedTicks >= CAN_STOP_TIMEOUT_TICKS_5MS)

        {

            g_canStopTimedOut = 1U;

            CanVehicleControl_EmergencyStop();

        }

        return;

    }

    if (g_canControlMode != CAN_MODE_AUTO)

    {

        return;

    }

    if (s_lastRxCount != g_canRxCount)

    {

        sint16 rpm = g_canRxTargetRpm;

        sint16 steer = g_canRxTargetSteerDeg;

        uint8 enable = g_canRxEnable;

        s_lastRxCount = g_canRxCount;

        g_canCommandAgeMs = 0U;

        g_canCommandFresh = 1U;

        g_canCommandRejected = 0U;

        if ((enable > 1U) ||

            (steer < (sint16)STEERING_MIN_DEG) ||

            (steer > (sint16)STEERING_MAX_DEG) ||

            ((float32)rpm > MAX_TEST_RPM) ||

            ((float32)rpm < -MAX_TEST_RPM))

        {

            g_canCommandRejected = 1U;

            CanVehicleControl_CommandStop();

        }

        else if (enable == 0U)
       {
           /* A zero/disable frame at rest must not exit AUTO.
            * This allows the bridge to send safe idle frames while
            * the operator prepares a separately armed command stream. */
           if (s_targetSignedRpm != 0.0f)
           {
               /* Driving: preserve the existing controlled CAN Ramp Stop. */
               CanVehicleControl_SelectManual();
               return;
           }

           /* No active drive target: keep AUTO and command safe zero.
            * RX age was reset above; missing CAN frames still fault. */
           g_canCommandArmed = 0U;
           g_canCommandFresh = 0U;
           s_targetSignedRpm = 0.0f;
           SteeringPwm_SetTargetAngle(0.0f);
           SpeedControl_StopNow();
           return;
       }

       else if (((rpm < 0) && (s_targetSignedRpm > 0.0f)) ||

                 ((rpm > 0) && (s_targetSignedRpm < 0.0f)))

        {

            g_canCommandRejected = 2U;

            CanVehicleControl_CommandStop();

        }

        else

        {

            if ((rpm == 0) && (s_targetSignedRpm != 0.0f))
            {
                /*
                 * Enable=1 with RPM=0 while driving: normal stop request from
                 * the upper controller. Use the controlled ramp stop (same as
                 * SELECT) instead of an instant PWM cut. AUTO is kept, so a new
                 * non-zero command can resume driving.
                 */
                SpeedControl_RequestCanRampStop();
            }

            g_canCommandArmed = 1U;

            s_targetSignedRpm = (float32)rpm;

            if (rpm > 0)

            {

                s_driveMode = GearDriveMode_Forward;

            }

            if (rpm < 0)

            {

                s_driveMode = GearDriveMode_Reverse;

            }

            SteeringPwm_SetTargetAngle((float32)steer);

        }

    }

    else if (g_canCommandAgeMs < CAN_COMMAND_TIMEOUT_MS)

    {

        g_canCommandAgeMs += 5U;

    }

    if (g_canCommandAgeMs >= CAN_COMMAND_TIMEOUT_MS)

    {

        /* Latch FAULT; fresh frames cannot automatically restart driving. */

        CanVehicleControl_EmergencyStop();

    }

    else if (g_canCommandArmed == 0U)

    {

        CanVehicleControl_CommandStop();

    }

}

float32 CanVehicleControl_GetTargetRpm(void)

{

    if (g_canControlMode != CAN_MODE_MANUAL)

    {

        return (s_targetSignedRpm < 0.0f) ? -s_targetSignedRpm : s_targetSignedRpm;

    }

    return GearManager_GetTargetRpm();

}

float32 CanVehicleControl_GetSignedTargetRpm(void)

{

    if (g_canControlMode != CAN_MODE_MANUAL)

    {

        return s_targetSignedRpm;

    }

    return GearManager_GetSignedTargetRpm();

}

GearDriveMode CanVehicleControl_GetDriveMode(void)

{

    if (g_canControlMode != CAN_MODE_MANUAL)

    {

        return s_driveMode;

    }

    return GearManager_GetDriveMode();

}
