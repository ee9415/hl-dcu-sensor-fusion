#ifndef SAFETY_MONITOR_H_
#define SAFETY_MONITOR_H_

#include "Ifx_Types.h"

/* Debug variables (ADS Expressions / safe to read while running). */
extern volatile uint8  g_watchdogEnabled;
extern volatile uint32 g_watchdogReload;
extern volatile uint32 g_resetStatusRaw;      /* SCU_RSTSTAT captured at boot */
extern volatile uint32 g_loopOverrunCount;    /* iterations that started late */
extern volatile uint32 g_loopOverrunFaultCount;
extern volatile uint8  g_loopMaxBacklog;
extern volatile uint32 g_loopExecTimeUs;      /* last 5 ms iteration */
extern volatile uint32 g_loopMaxExecTimeUs;

/* Call once, after all initialization and right before the main loop. */
void SafetyMonitor_Start(void);

/* Call at the start of every 5 ms iteration (after Take5msFlag). */
void SafetyMonitor_LoopBegin(void);

/* Call at the end of every 5 ms iteration. Services the watchdog. */
void SafetyMonitor_LoopEnd(void);

#endif /* SAFETY_MONITOR_H_ */
