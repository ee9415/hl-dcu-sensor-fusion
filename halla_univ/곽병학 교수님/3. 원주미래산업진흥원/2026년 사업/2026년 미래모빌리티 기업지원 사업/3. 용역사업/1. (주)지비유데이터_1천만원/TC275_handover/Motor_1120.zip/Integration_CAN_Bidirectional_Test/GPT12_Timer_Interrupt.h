#ifndef GPT12_TIMER_INTERRUPT_H_
#define GPT12_TIMER_INTERRUPT_H_

#include "Ifx_Types.h"

void Gpt12Timer_Init(void);
boolean Gpt12Timer_Take5msFlag(void);

extern volatile uint32 g_tick100us;
extern volatile uint8 g_flag5ms;
extern volatile uint32 g_gpt12IsrCount;

#endif /* GPT12_TIMER_INTERRUPT_H_ */
