#include "GPT12_Timer_Interrupt.h"

#include "App_Config.h"
#include "Board_Pins.h"
#include "Encoder_GPT12.h"
#include "IfxCpu.h"
#include "IfxCpu_Irq.h"
#include "IfxGpt12.h"
#include "IfxPort.h"
#include "IfxSrc.h"

#define ISR_PRIORITY_GPT12_T6         (6U)

volatile uint32 g_tick100us = 0U;
volatile uint8 g_flag5ms = 0U;
volatile uint32 g_gpt12IsrCount = 0U;

static uint8 g_tick5msDivider = 0U;
static uint16 g_t6ReloadValue = 1U;

IFX_INTERRUPT(Gpt12Timer_Isr, 0, ISR_PRIORITY_GPT12_T6);

static void Gpt12Timer_InitDebugPin(void)
{
    IfxPort_setPinModeOutput(ISR_CHECK_PORT,
                             ISR_CHECK_PIN,
                             IfxPort_OutputMode_pushPull,
                             IfxPort_OutputIdx_general);
    IfxPort_setPinLow(ISR_CHECK_PORT, ISR_CHECK_PIN);
}

void Gpt12Timer_Init(void)
{
    volatile Ifx_SRC_SRCR *src;
    float32 t6Frequency;
    uint32 reloadTicks;

    Gpt12Timer_InitDebugPin();

    IfxGpt12_enableModule(&MODULE_GPT120);
    IfxGpt12_setGpt2BlockPrescaler(&MODULE_GPT120, IfxGpt12_Gpt2BlockPrescaler_16);
    IfxGpt12_T6_setMode(&MODULE_GPT120, IfxGpt12_Mode_timer);
    IfxGpt12_T6_setDirectionSource(&MODULE_GPT120, IfxGpt12_TimerDirectionSource_internal);
    IfxGpt12_T6_setTimerDirection(&MODULE_GPT120, IfxGpt12_TimerDirection_down);
    IfxGpt12_T6_setTimerPrescaler(&MODULE_GPT120, IfxGpt12_TimerInputPrescaler_16);

    t6Frequency = IfxGpt12_T6_getFrequency(&MODULE_GPT120);
    reloadTicks = (uint32)(t6Frequency * ((float32)GPT12_ISR_PERIOD_US / 1000000.0f));

    if (reloadTicks == 0U)
    {
        reloadTicks = 1U;
    }
    else if (reloadTicks > 0xFFFFU)
    {
        reloadTicks = 0xFFFFU;
    }

    g_t6ReloadValue = (uint16)reloadTicks;
    IfxGpt12_T6_setTimerValue(&MODULE_GPT120, g_t6ReloadValue);

    src = IfxGpt12_T6_getSrc(&MODULE_GPT120);
    IfxSrc_init(src, IfxSrc_Tos_cpu0, ISR_PRIORITY_GPT12_T6);
    IfxSrc_enable(src);

    g_tick100us = 0U;
    g_flag5ms = 0U;
    g_tick5msDivider = 0U;
    g_gpt12IsrCount = 0U;

    IfxGpt12_T6_run(&MODULE_GPT120, IfxGpt12_TimerRun_start);
}

void Gpt12Timer_Isr(void)
{
    g_tick100us++;
    g_gpt12IsrCount++;

    IfxPort_togglePin(ISR_CHECK_PORT, ISR_CHECK_PIN);

    /* Read GPT12 T2/T3 hardware counters into 32-bit software accumulation. */
    EncoderGpt12_Service100us();

    g_tick5msDivider++;
    if (g_tick5msDivider >= CONTROL_LOOP_TICK100US)
    {
        g_tick5msDivider = 0U;

        if (g_flag5ms < 0xFFU)
        {
            g_flag5ms++;
        }
    }

    IfxGpt12_T6_setTimerValue(&MODULE_GPT120, g_t6ReloadValue);
}

boolean Gpt12Timer_Take5msFlag(void)
{
    boolean interruptState;
    boolean available = FALSE;

    interruptState = IfxCpu_disableInterrupts();

    if (g_flag5ms != 0U)
    {
        g_flag5ms--;
        available = TRUE;
    }

    IfxCpu_restoreInterrupts(interruptState);
    return available;
}
