#ifndef SAFETY_CONFIG_H_
#define SAFETY_CONFIG_H_

/*
 * Safety / robustness settings (2026-11 update).
 * Kept separate from App_Config.h so the tuned vehicle values there
 * are not touched by this update.
 */

/* ============================================================================================= */
/* CPU0 WATCHDOG                                                                                 */
/* ============================================================================================= */

/*
 * 1 = enable CPU0 watchdog after initialization and service it every 5 ms.
 * Default 0: turn on after the bench test described in CHANGES_KO.txt.
 *
 * When the main loop stops servicing it for WATCHDOG_TIMEOUT_MS, the MCU
 * resets and every motor output is released.
 */
#define WATCHDOG_ENABLE                    (0U)
#define WATCHDOG_TIMEOUT_MS                (100U)

/*
 * Watchdog bench test ONLY. 0 = off.
 * N > 0: the main loop deliberately hangs N ms after boot so the watchdog
 * reset can be observed. Never leave non-zero for driving.
 */
#define WATCHDOG_TEST_HANG_AFTER_MS        (0U)


/* ============================================================================================= */
/* 5 ms LOOP OVERRUN                                                                             */
/* ============================================================================================= */

/*
 * Pending 5 ms ticks at the start of a loop iteration means the previous
 * iteration took too long. Backlog >= this value -> drop the backlog and
 * latch FAULT (motor stop; SELECT to recover).
 * 4 ticks = the loop is already 20 ms late.
 */
#define LOOP_OVERRUN_FAULT_BACKLOG         (4U)


/* ============================================================================================= */
/* CAN BUS-OFF RECOVERY                                                                          */
/* ============================================================================================= */

/* Wait this long after bus-off before re-enabling the CAN node. */
#define CAN_BUSOFF_RECOVERY_DELAY_MS       (100U)

/* More than CAN_BUSOFF_MAX_RECOVERIES within the window -> stop recovering
 * (wiring problem); a power cycle / reset is required. */
#define CAN_BUSOFF_MAX_RECOVERIES          (3U)
#define CAN_BUSOFF_WINDOW_MS               (10000U)


/* ============================================================================================= */
/* CAN 0x200 INTEGRITY (alive counter + checksum)                                                */
/* ============================================================================================= */

/*
 * 1 = 0x200 frames must carry:
 *     byte 6 : alive counter, +1 every frame (0..255, wraps)
 *     byte 7 : checksum = byte0 ^ byte1 ^ ... ^ byte6
 * Frames with a wrong checksum, or with the same counter as the previous
 * accepted frame, are discarded (-> AUTO times out after 200 ms -> FAULT).
 *
 * Default 0: CanKing Traffic Generator sends a constant frame.
 * Set 1 once the upper controller implements the counter/checksum.
 */
#define CAN_RX_INTEGRITY_CHECK_ENABLE      (0U)

#endif /* SAFETY_CONFIG_H_ */
