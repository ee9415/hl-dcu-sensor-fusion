#include "Ifx_Types.h"
#include "IfxCpu.h"
#include "IfxScuWdt.h"
#include "IfxStm.h"
#include "Bsp.h"

#include "ControlLoop.h"
#include "Can_CommandRx.h"
#include "Can_VehicleControl.h"
#include "Drive_PWM.h"
#include "Encoder_GPT12.h"
#include "Gear_Manager.h"
#include "GPT12_Timer_Interrupt.h"
#include "Ps2_Controller.h"
#include "Speed_Calculate.h"
#include "Speed_Control.h"
#include "Steering_ADC.h"
#include "Steering_PWM.h"
#include "VehicleManager.h"
#include "Safety_Monitor.h"

IFX_ALIGN(4) IfxCpu_syncEvent cpuSyncEvent = 0;

static void Main_WaitMs(uint32 ms)
{
    sint32 frequency;
    Ifx_TickTime ticks;

    frequency = IfxStm_getFrequency(&MODULE_STM0);
    ticks = (Ifx_TickTime)(((uint64)frequency * ms) / 1000U);
    wait(ticks);
}

int core0_main(void)
{
    IfxCpu_enableInterrupts();

    IfxScuWdt_disableCpuWatchdog(IfxScuWdt_getCpuWatchdogPassword());
    IfxScuWdt_disableSafetyWatchdog(IfxScuWdt_getSafetyWatchdogPassword());

    IfxCpu_emitEvent(&cpuSyncEvent);
    IfxCpu_waitEvent(&cpuSyncEvent, 1);

    /* --------------------------------------------------------------------- */
    /* Hardware / driver initialization                                      */
    /* --------------------------------------------------------------------- */
    EncoderGpt12_Init();
    DrivePwm_Init();
    SteeringPwm_Init();
    SteeringAdc_Init();

    /* --------------------------------------------------------------------- */
    /* Application initialization                                            */
    /* --------------------------------------------------------------------- */
    GearManager_Init();
    SpeedCalc_Init();
    SpeedControl_Init();
    VehicleManager_Init();
    ControlLoop_Init();
    CanCommandRx_Init();
    CanVehicleControl_Init();

    /* Safe center before enabling manual input. */
    SteeringPwm_SetAngleImmediate(0.0f);
    Main_WaitMs(500U);

    /* PS2 is initialized while traction is stopped. */
    Ps2Controller_Init();

    /* Start 100 us scheduler last. It also services the GPT12 encoder counters. */
    Gpt12Timer_Init();

    /* Watchdog (if enabled in Safety_Config.h) starts only after all init. */
    SafetyMonitor_Start();

    while (1)
    {
        if (Gpt12Timer_Take5msFlag() != FALSE)
        {
            SafetyMonitor_LoopBegin();      /* 5 ms overrun check */

            CanCommandRx_BusOffMonitor5ms();
            CanCommandRx_Poll();
            ControlLoop_5ms();
            CanCommandRx_PollTx5ms();

            SafetyMonitor_LoopEnd();        /* exec time + watchdog service */
        }
    }

    return 0;
}
