#ifndef APP_CONFIG_H_
#define APP_CONFIG_H_

#include "Ifx_Types.h"


/* ============================================================================================= */
/* SCHEDULER                                                                                     */
/* ============================================================================================= */

#define GPT12_ISR_PERIOD_US            (100U)

#define CONTROL_LOOP_PERIOD_MS         (5U)
#define CONTROL_LOOP_TICK100US         (50U)

/*
 * Task divisors from 5 ms base
 */
#define ADC_TASK_DIV                   (2U)   /* 10 ms */
#define PS2_TASK_DIV                   (4U)   /* 20 ms */
#define STEERING_TASK_DIV              (4U)   /* 20 ms */
#define SPEED_PI_TASK_DIV              (20U)  /* 100 ms */


/* ============================================================================================= */
/* ENCODER / SPEED                                                                               */
/* ============================================================================================= */

#define ENCODER_PPR                    (550U)
#define ENCODER_X4                     (4U)
#define MOTOR_GEAR_RATIO               (18.0f)

#define COUNTS_PER_REV                 \
    ((float32)ENCODER_PPR *            \
     (float32)ENCODER_X4 *             \
     MOTOR_GEAR_RATIO)

/*
 * Encoder direction sign
 *
 * Forward driving must produce:
 *
 * Left RPM  > 0
 * Right RPM > 0
 */
#define LEFT_ENCODER_COUNT_SIGN        (1)
#define RIGHT_ENCODER_COUNT_SIGN       (-1)


/* ============================================================================================= */
/* GEAR MAP                                                                                      */
/* ============================================================================================= */

#define GEAR_MIN                       (0U)
#define GEAR_MAX                       (4U)

#define GEAR_0_RPM                     (0.0f)
#define GEAR_1_RPM                     (30.0f) /* 30 */
#define GEAR_2_RPM                     (80.0f) /* 65 */
#define GEAR_3_RPM                     (150.0f) /* 100 */
#define GEAR_4_RPM                     (200.0f) /* 140 */
/* 200rpm = 6.8km/h */

/*
 * Maximum RPM allowed during current testing.
 */
/* Runtime mode switching: START=AUTO, SELECT=MANUAL.
 * Mode changes require wheel RPM close to zero. No automatic restart after
 * CAN timeout; SELECT must re-arm MANUAL before another START request.
 */
#define CAN_COMMAND_TIMEOUT_MS         (200U)
#define MODE_SWITCH_MAX_RPM            (3.0f)
#define PS2_BTN_SELECT                 (0x0001U)
#define PS2_BTN_START                  (0x0008U)

#define MAX_TEST_RPM                   (200.0f) /* 140 */


/* ============================================================================================= */
/* SPEED PI                                                                                      */
/* ============================================================================================= */

/*
 * Normal driving PI
 */
#define SPEED_PI_KP                    (0.20f)
#define SPEED_PI_KI                    (0.60f)   /* was 0.08: integral too slow (load never recovered) */

/*
 * Controlled stop PI
 */
#define STOP_PI_KP                     (0.40f)   /* rpm 200기준 밀리면 0.5 ~ 0.6 */
#define STOP_PI_KI                     (0.05f)

/*
 * Normal-drive integral limit, expressed as the duty (%) the I term may add
 * or remove: |Ki * I| <= SPEED_PI_I_DUTY_LIMIT. Independent of Ki.
 */
#define SPEED_PI_I_DUTY_LIMIT          (15.0f)

/*
 * Integral anti-windup limits (controlled-stop PI)
 */
#define SPEED_PI_INTEGRAL_MIN          (-50.0f)
#define SPEED_PI_INTEGRAL_MAX          (50.0f)

/*
 * PWM output limits
 */
#define MIN_DUTY_PERCENT               (0.0f)
#define MAX_DUTY_PERCENT               (95.0f) /* 90 */


/*
 * Target-RPM rate limiter (normal drive, MANUAL and AUTO).
 * Applied every 5 ms to the commanded target before FF + PI.
 *
 * 0.5 RPM / 5 ms = 100 RPM/s  ->  0 -> 140 RPM in about 1.4 s.
 * Tune on the vehicle: larger = quicker response, smaller = softer start.
 */
#define SPEED_TARGET_ACCEL_RPM_PER_5MS (0.5f)
#define SPEED_TARGET_DECEL_RPM_PER_5MS (0.5f)

/*
 * Direction guard: the H-bridge may be energised in a direction only when
 * no wheel turns AGAINST that direction faster than this.
 */
#define DIRECTION_CHANGE_MAX_RPM       (3.0f)


/* ============================================================================================= */
/* SPEED FEEDFORWARD                                                                            */
/* ============================================================================================= */

/*
 * Base Duty =
 *
 *     A * TargetRPM + B
 */
/*
 * Re-fitted 2026-10-30 from corridor CAN logs (0x102/0x103), steady state:
 *   gear 2: 27.8 % -> 66 RPM,   gear 4: 58.7 % -> 143 RPM
 *   => A = 0.401, B = 1.31   (previous: A = 0.408, B = 0.98)
 */
#define SPEED_FEEDFORWARD_A            (0.401f)
#define SPEED_FEEDFORWARD_B            (1.31f)


/* ============================================================================================= */
/* CONTROLLED STOP                                                                               */
/* ============================================================================================= */

/*
 * Gear-specific target RPM reduction.
 *
 * Updated every 100 ms.
 */
#define STOP_TARGET_RAMP_GEAR1_RPM_PER_100MS     (8.0f)
#define STOP_TARGET_RAMP_GEAR2_RPM_PER_100MS     (8.0f)
#define STOP_TARGET_RAMP_GEAR3_RPM_PER_100MS     (12.0f)
#define STOP_TARGET_RAMP_GEAR4_RPM_PER_100MS     (16.0f)   /* rpm 200기준 밀리면 20 ~ 24 */

#define STOP_TARGET_RAMP_DEFAULT_RPM_PER_100MS   (5.0f)

/*
 * Normal controlled-stop Duty slew.
 *
 * Desired Duty is calculated every 100 ms.
 * Applied Duty changes every 5 ms.
 */
#define STOP_DUTY_RAMP_PER_5MS                   (1.5f)   /* rpm 200기준 밀리면 2.0 */

/*
 * Final complete-stop threshold.
 */
#define STOP_COMPLETE_RPM                        (3.0f)


/* ============================================================================================= */
/* LOW SPEED REVERSE-TORQUE BRAKING                                                             */
/* ============================================================================================= */

/*
 * Reverse braking becomes available only when:
 *
 * 1. Stop target == 0 RPM
 * 2. Left actual RPM  <= 10 RPM
 * 3. Right actual RPM <= 10 RPM
 */
#define STOP_REVERSE_ENABLE_RPM                  (15.0f)

/*
 * Proportional reverse braking gain.
 *
 * Desired Reverse Duty =
 *
 *     STOP_REVERSE_KP * Actual RPM
 *
 * Example:
 *
 * 10 RPM -> 3.0 %
 *  8 RPM -> 2.4 %
 *  6 RPM -> 1.8 %
 *  5 RPM -> 1.5 %
 *  4 RPM -> 1.2 %
 */
#define STOP_REVERSE_KP                          (0.30f)

/*
 * Maximum reverse braking Duty.
 */
#define STOP_REVERSE_DUTY_MAX                    (4.5f)

/*
 * Maximum reverse Duty change every 5 ms.
 *
 * This is independent from STOP_DUTY_RAMP_PER_5MS.
 */
#define STOP_REVERSE_DUTY_STEP_5MS               (0.5f)

/*
 * Zero-PWM waiting time before direction reversal.
 *
 * 1 tick = 5 ms
 */
#define STOP_REVERSE_ZERO_WAIT_TICKS             (1U)


/* ============================================================================================= */
/* MOTOR PWM                                                                                     */
/* ============================================================================================= */

#define MOTOR_PWM_PERIOD_TICKS         (5000U)


/* ============================================================================================= */
/* STEERING                                                                                      */
/* ============================================================================================= */

#define SERVO_PERIOD_TICKS             (7813U)

#define SERVO_MIN_US                   (1180U)
#define SERVO_CENTER_US                (1570U)
#define SERVO_MAX_US                   (1880U)

#define STEERING_MIN_DEG               (-24.0f) /* -24 */
#define STEERING_MAX_DEG               (24.0f) /* 24 */

#define STEERING_STEP_DEG              (1.0f)


/* ============================================================================================= */
/* ADC                                                                                           */
/* ============================================================================================= */

#define ADC_MAX_VALUE                  (4095.0f)
#define ADC_REFERENCE_VOLTAGE          (3.3f)


/* ============================================================================================= */
/* PS2                                                                                           */
/* ============================================================================================= */

#define PS2_PACKET_SIZE                (9U)
#define PS2_BIT_DELAY_US               (8U)
#define PS2_LOSS_CONFIRM_CNT           (5U)

#define PS2_BTN_RIGHT                  (0x0020U)
#define PS2_BTN_LEFT                   (0x0080U)

#define PS2_BTN_TRIANGLE               (0x1000U)
#define PS2_BTN_CIRCLE                 (0x2000U)
#define PS2_BTN_CROSS                  (0x4000U)
#define PS2_BTN_SQUARE                 (0x8000U)

#define PS2_STEERING_DEADZONE_RAW      (10U)


#endif /* APP_CONFIG_H_ */
