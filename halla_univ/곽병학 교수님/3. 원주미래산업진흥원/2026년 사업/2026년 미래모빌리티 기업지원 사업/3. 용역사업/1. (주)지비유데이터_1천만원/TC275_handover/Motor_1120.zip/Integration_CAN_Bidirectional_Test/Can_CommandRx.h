#ifndef CAN_COMMANDRX_H_
#define CAN_COMMANDRX_H_

#include "Ifx_Types.h"

/* Debug variables: Watch these in AURIX Development Studio. */
extern volatile sint16 g_canRxTargetRpm;
extern volatile sint16 g_canRxTargetSteerDeg;
extern volatile uint8  g_canRxEnable;
extern volatile uint8  g_canRxStopMode;
extern volatile uint32 g_canRxCount;
extern volatile uint32 g_canRxErrorCount;
extern volatile uint32 g_canRxInitModuleStatus;
extern volatile uint32 g_canRxInitNodeStatus;
extern volatile uint32 g_canRxInitMsgObjStatus;
extern volatile uint8  g_canRxValid;

void CanCommandRx_Init(void);
void CanCommandRx_Poll(void);

#endif

/* 100ms CAN feedback transmission (call from the 5ms main scheduler). */
void CanCommandRx_PollTx5ms(void);
extern volatile uint32 g_canTxSteerCount;
extern volatile uint32 g_canTxRpmCount;
extern volatile uint32 g_canTxBusyCount;
extern volatile uint32 g_canTxOtherErrorCount;
extern volatile uint32 g_canTxInitSteerStatus;
extern volatile uint32 g_canTxInitRpmStatus;
extern volatile uint32 g_canTxCtrlCount;
extern volatile uint32 g_canTxInitCtrlStatus;

/* Bus-off monitor + recovery (call every 5 ms). See Safety_Config.h. */
void CanCommandRx_BusOffMonitor5ms(void);
extern volatile uint8  g_canBusOff;
extern volatile uint32 g_canBusOffCount;
extern volatile uint32 g_canBusOffRecoveryCount;
extern volatile uint8  g_canBusOffLocked;
extern volatile uint8  g_canTxErrorCounter;
extern volatile uint8  g_canRxErrorCounter;

/* 0x200 integrity (byte6 alive counter, byte7 XOR checksum). */
extern volatile uint8  g_canRxAliveCounter;
extern volatile uint8  g_canRxChecksum;
extern volatile uint32 g_canRxChecksumErrorCount;
extern volatile uint32 g_canRxAliveErrorCount;
extern volatile uint32 g_canRxAliveGapCount;
