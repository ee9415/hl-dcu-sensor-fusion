# aurix_can_bridge (새 노트북용 수정판)

이전 노트북의 `aurix_can_bridge` 를 그대로 살리고, 지금 TC275 펌웨어(Integration_CAN_Bidirectional_Test)에 맞게 **필요한 부분만** 고쳤습니다.
ROS → TC275 로 `0x200` 주행 명령을 보내고, `0x101`/`0x102` 피드백을 토픽으로 내보냅니다.

> ⚠️ 첫 시험은 **반드시 바퀴를 띄운 상태**, 조이스틱을 손에 든 상태로 하세요. AUTO 중 **X(CROSS) 버튼 = 즉시 정지(FAULT)** 입니다.

---

## 1. 바뀐 점 (이전 코드 대비)

| # | 바뀐 것 | 이유 |
|---|---|---|
| 1 | `0x200` byte6 = alive counter(매 프레임 +1), byte7 = byte0~6 XOR | 펌웨어의 무결성 검사(`CAN_RX_INTEGRITY_CHECK_ENABLE`)를 켜면 이전 코드(byte5~7 = 0)는 모든 프레임이 버려져 200 ms 뒤 FAULT. 지금은 검사가 꺼져 있어 그대로도 동작하지만, 미리 맞춰 둠 (꺼져 있어도 해가 없음) |
| 2 | `/cmd_vel` (geometry_msgs/Twist) 입력 추가 | 상위 제어(목표 헤딩 등)가 ROS 표준 속도 명령을 쓰도록. v → RPM(바퀴 지름 0.18 m), 요레이트 → 조향 `atan(L·ω/v)` (L = 0.59 m) |
| 3 | `/cmd_vel` 조향 부호 뒤집기 | ROS 는 +왼쪽, TC275 는 +오른쪽 |
| 4 | 조향 한계 ±30 → **±24°** (`max_steer_deg`, 24 넘게 설정 불가) | 실측 최대 조향각 ±24°. 펌웨어는 범위 밖 조향이 오면 명령을 거부하고 정지시킴 |
| 5 | `/cmd_vel` 속도 상한 `max_speed_mps` 기본 **0.30 m/s** (≈32 RPM) | 처음엔 느리게. 문자열 명령의 RPM 상한도 `max_rpm`(기본 140, 최대 200) 으로 파라미터화 |
| 6 | `/cmd_vel` 후진 기본 금지 (`allow_reverse:=false` 면 음수 속도 → 0) | 펌웨어는 주행 중 방향이 바뀌는 명령을 받으면 램프 없이 즉시 정지함 |
| 7 | 송신 주기 50 ms → **20 ms** (`tx_period_sec`, 10~50 ms만 허용) | 펌웨어 타임아웃 200 ms. 50 ms면 PC가 잠깐 멈출 때 여유가 4프레임뿐 |
| 8 | 종료할 때 정지 프레임 1개 → **5개** (alive 증가) | 프레임 1개가 유실/중복 판정돼도 정지 명령이 확실히 들어가게 |
| 9 | 0x102 의 모드가 바뀔 때 로그 (`TC275 mode: AUTO` 등) | 지금 AUTO 인지 터미널에서 바로 보이게 |
| 10 | `package.xml` 에 `geometry_msgs`, `python3-can` 추가 / backup 파일·`__pycache__` 삭제 | 정리 |

**그대로 둔 것:** `allow_motion` + `ARM` 2단계 잠금, 입력 0.2 s 끊기면 DISARM(→ 0 명령), 잘못된 명령이면 DISARM, CAN 송신 실패면 DISARM, 피드백 토픽 이름 전부, 문자열 명령 `/aurix/can/command` (**TC275 단위, +오른쪽**).

---

## 2. 펌웨어 동작 요약 (코드에서 확인한 것, 펌웨어는 안 건드림)

- `0x200` 표준 ID, DLC 8, 500 kbit/s
  - byte0-1 목표 RPM int16 LE, byte2-3 조향[deg] int16 LE (+오른쪽), byte4 enable, byte5 stop mode, byte6 alive, byte7 XOR
- **AUTO 들어가기:** MANUAL 상태 + 바퀴 정지(좌우 |RPM| < 3) 에서 조이스틱 **START**
  - START 누르는 순간부터 200 ms 안에 `0x200` 이 계속 와야 함 → **노드를 먼저 켜고** START
- **MANUAL 로 돌아가기:** **SELECT** (주행 중이면 램프 감속 후 MANUAL). FAULT 에서 나올 때도 SELECT
- **비상정지:** AUTO 중 **X(CROSS)** → FAULT
- `0x200` 200 ms 끊김 → FAULT (자동 재시작 없음, SELECT 필요)
- enable=0: 주행 중이면 램프 정지 후 MANUAL / 정지 상태면 AUTO 유지하고 0 명령
- enable=1, RPM=0: 주행 중이면 램프 정지, AUTO 유지 (다시 RPM 주면 출발)
- 거부(즉시 정지): enable>1, |RPM|>200(`MAX_TEST_RPM`), 조향이 `STEERING_MIN/MAX_DEG` 밖, 주행 중 전진↔후진 전환
- 가속 제한: 펌웨어가 100 RPM/s 로 목표를 천천히 올림
- RPM ↔ 속도: 1 RPM = π·0.18/60 = **0.00942 m/s** (32 RPM ≈ 0.30 m/s, 200 RPM ≈ 1.9 m/s)

---

## 3. 설치 / 빌드

```bash
# 다운받은 aurix_can_bridge 폴더를 src 로 (vehicle_localization 과 별개 패키지)
cp -r aurix_can_bridge ~/ros2_ws/src/
cd ~/ros2_ws
colcon build --packages-select aurix_can_bridge
source install/setup.bash
```
`can-utils` 없으면: `sudo apt install can-utils`

---

## 4. 벤치 테스트 (바퀴 띄우고, 한 단계씩)

### 0단계: 준비
- 차를 받침대에 올려 **바퀴가 땅에 안 닿게**
- 조이스틱 손에. TC275 는 **MANUAL** 상태로 시작

### 1단계: CAN 살아 있는지
```bash
ip -details link show can0        # state UP, bitrate 500000 확인
candump -td can0,101:7FF,102:7FF  # 0x101, 0x102 가 약 0.1 s 간격으로 나와야 함
```

### 2단계: 노드 켜기 (움직임 잠금 상태)
터미널 A:
```bash
ros2 run aurix_can_bridge can_bridge_node
```
터미널 B:
```bash
candump -td can0,200:7FF
```
기대값 (약 0.02 s 간격):
```
 (0.020000)  can0  200   [8]  00 00 00 00 00 00 2A 2A
 (0.020000)  can0  200   [8]  00 00 00 00 00 00 2B 2B
```
- byte6 이 매번 1씩 증가, byte7 = 앞 7바이트 XOR (전부 0 이면 byte6 과 같음)

### 3단계: AUTO 진입 (아직 0 명령)
- 노드 켜진 상태에서 조이스틱 **START**
- 터미널 A 로그에 `TC275 mode: AUTO`
- 0 명령만 가므로 아무것도 안 움직여야 정상

### 4단계: 움직임 허용하고 조향만 (바퀴 회전 0)
터미널 A 에서 Ctrl+C → TC275 는 200 ms 뒤 **FAULT** (정상) → **SELECT** 로 MANUAL
```bash
ros2 run aurix_can_bridge can_bridge_node --ros-args -p allow_motion:=true
```
다시 **START** → AUTO 확인 후, 터미널 C:
```bash
ros2 topic pub --once /aurix/can/command std_msgs/msg/String "{data: ARM}"
ros2 topic pub -r 20 /aurix/can/command std_msgs/msg/String "{data: '0,10,1'}"
```
- 문자열 명령은 **TC275 단위** → `+10` = **오른쪽** 10°
- candump: `200 [8] 00 00 0A 00 01 00 ..`
- 확인 후 Ctrl+C (pub 중지) → 0.2 s 안에 로그 `DISARMED: command stream timeout`, 바퀴 직진으로

### 5단계: /cmd_vel 로 조향 부호 확인 (바퀴가 천천히 돎)
```bash
ros2 topic pub --once /aurix/can/command std_msgs/msg/String "{data: ARM}"
ros2 topic pub -r 20 /cmd_vel geometry_msgs/msg/Twist "{linear: {x: 0.2}, angular: {z: 0.1}}"
```
- 기대: **왼쪽**으로 약 16° (ROS +왼쪽), 바퀴 21 RPM 전진
- candump: `200 [8] 15 00 F0 FF 01 00 ..` (0x15 = 21 RPM, 0xFFF0 = -16 = TC275 왼쪽)
- `angular.z: -0.1` 로 바꾸면 **오른쪽** (`10 00`)
- 피드백: `ros2 topic echo /aurix/can/actual_rpm` → 약 21

### 6단계: 정지 동작 확인
1. `/cmd_vel` pub 을 Ctrl+C → 0.2 s 안에 DISARM → enable=0 → 펌웨어 램프 정지 → 로그 `STOPPING` → `MANUAL`
2. 다시 START, ARM, `/cmd_vel` pub 후 `linear.x: 0.0` 으로 → 램프 정지, **AUTO 유지**
3. 주행 중 **X** → 즉시 `FAULT`. **SELECT** 로 복귀
4. 주행 중 노드 Ctrl+C → 정지 프레임 5개 후 200 ms 뒤 `FAULT` (정상)

여기까지 다 맞으면 땅에서 `max_speed_mps` 기본(0.3) 그대로 짧게 시험.

---

## 5. 파라미터

| 이름 | 기본 | 뜻 |
|---|---|---|
| allow_motion | false | true 가 아니면 항상 0 명령 |
| can_interface | can0 | |
| command_timeout_sec | 0.20 | 입력이 이보다 오래 끊기면 DISARM (0.05~1.0) |
| tx_period_sec | 0.02 | 0x200 송신 주기 (0.01~0.05) |
| max_rpm | 140 | 문자열/`cmd_vel` 공통 RPM 상한 (최대 200) |
| max_steer_deg | 24 | 조향 상한 (최대 24) |
| cmd_vel_topic | /cmd_vel | |
| max_speed_mps | 0.30 | `cmd_vel` 속도 상한 (최대 1.0) |
| allow_reverse | false | `cmd_vel` 후진 허용 |
| wheel_diameter_m | 0.18 | |
| wheelbase_m | 0.59 | |
| min_speed_for_steer_mps | 0.05 | 이보다 느리면 조향 0 (제자리 회전 불가) |

## 6. 토픽
- 입력: `/aurix/can/command` (String: `ARM`, `DISARM`, `rpm,조향,enable` — TC275 단위), `/cmd_vel` (Twist — ROS 단위)
- 출력: `/aurix/can/control_mode`, `/aurix/can/actual_rpm`, `/aurix/can/left_rpm`, `/aurix/can/right_rpm`, `/aurix/can/rpm_valid`, `/aurix/can/target_steering`, `/aurix/can/actual_steering_adc`, `/aurix/can/steering_adc_valid`, `/aurix/can/steering_raw`, `/aurix/can/speed_raw`
- `/wheel/twist` (wheel_odom)도 0x102 를 읽는데, 소켓이 따로라 같이 켜도 됨

---

## 7. 펌웨어 쪽 메모 (고치지 않음, 판단 필요)

1. **`CAN_RX_INTEGRITY_CHECK_ENABLE` 가 0** (Safety_Config.h). 노드가 이제 alive/XOR 를 보내니, 벤치 2단계 통과 후 **1로 켜는 것 권장**. 켜면 멈춘 PC가 같은 프레임을 반복 보내는 경우도 FAULT 로 잡힘
2. byte5 stop mode 는 펌웨어가 읽기만 하고 **안 씀** (노드는 0)
3. 주행 중 전진↔후진 명령 → **램프 없이 즉시 정지** (`SpeedControl_StopNow`). 그래서 노드에서 후진 기본 금지
