#ifndef CONTROL_LOOP_H_
#define CONTROL_LOOP_H_

#include "Ifx_Types.h"

void ControlLoop_Init(void);
void ControlLoop_5ms(void);

extern volatile uint32 g_controlLoopCount;
extern volatile uint32 g_controlLoop10msCount;
extern volatile uint32 g_controlLoop20msCount;
extern volatile uint32 g_controlLoop100msCount;

#endif /* CONTROL_LOOP_H_ */
