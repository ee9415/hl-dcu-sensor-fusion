#include "Ps2_Controller.h"

#include "App_Config.h"
#include "Board_Pins.h"
#include "IfxPort.h"
#include "IfxStm.h"


/* ============================================================================================= */
/* DEBUG VARIABLES                                                                               */
/* ============================================================================================= */

volatile uint8 g_ps2Raw0 = 0xFFU;
volatile uint8 g_ps2Raw1 = 0xFFU;
volatile uint8 g_ps2Raw2 = 0xFFU;
volatile uint8 g_ps2Raw3 = 0xFFU;
volatile uint8 g_ps2Raw4 = 0xFFU;
volatile uint8 g_ps2Raw5 = 0x80U;
volatile uint8 g_ps2Raw6 = 0x80U;
volatile uint8 g_ps2Raw7 = 0x80U;
volatile uint8 g_ps2Raw8 = 0x80U;

volatile uint8 g_ps2ReceiverAlive = 0U;
volatile uint8 g_ps2PadConnected = 0U;

volatile uint8 g_ps2Mode = 0xFFU;
volatile uint8 g_ps2Status = 0xFFU;

volatile uint16 g_ps2Buttons = 0U;

volatile uint8 g_ps2Rx = 0x80U;
volatile uint8 g_ps2Ry = 0x80U;
volatile uint8 g_ps2Lx = 0x80U;
volatile uint8 g_ps2Ly = 0x80U;

volatile uint32 g_ps2PollCount = 0U;
volatile uint32 g_ps2OkCount = 0U;
volatile uint32 g_ps2ErrCount = 0U;

volatile uint8 g_ps2LossCount = 0U;


/*
 * Steering debug
 *
 * 0   = full left
 * 128 = center
 * 255 = full right
 */
volatile uint8 g_ps2SteeringRaw = 128U;


/*
 * 1 = analog steering active
 * 0 = digital fallback
 */
volatile uint8 g_ps2SteeringAnalogActive = 0U;


/* ============================================================================================= */
/* INTERNAL                                                                                      */
/* ============================================================================================= */

static uint8 g_ps2Raw[PS2_PACKET_SIZE];


/* ============================================================================================= */
/* DELAY                                                                                         */
/* ============================================================================================= */

static void Ps2_DelayUs(uint32 us)
{
    sint32 ticks;

    ticks =
            IfxStm_getTicksFromMicroseconds(
                    &MODULE_STM0,
                    us);

    if (ticks <= 0)
    {
        ticks = 1;
    }

    IfxStm_waitTicks(
            &MODULE_STM0,
            (uint32)ticks);
}


static void Ps2_DelayMs(uint32 ms)
{
    while (ms > 0U)
    {
        Ps2_DelayUs(1000U);
        ms--;
    }
}


/* ============================================================================================= */
/* GPIO                                                                                          */
/* ============================================================================================= */

static void Ps2_SetCmd(uint8 high)
{
    if (high != 0U)
    {
        IfxPort_setPinHigh(
                PS2_CMD_PORT,
                PS2_CMD_PIN);
    }
    else
    {
        IfxPort_setPinLow(
                PS2_CMD_PORT,
                PS2_CMD_PIN);
    }
}


static uint8 Ps2_ReadData(void)
{
    return
            (IfxPort_getPinState(
                    PS2_DATA_PORT,
                    PS2_DATA_PIN)
                    != FALSE)
            ?
            1U
            :
            0U;
}


/* ============================================================================================= */
/* BYTE TRANSFER                                                                                 */
/* ============================================================================================= */

static uint8 Ps2_XferByte(uint8 tx)
{
    uint8 rx = 0U;
    uint8 bit;

    for (bit = 0U; bit < 8U; bit++)
    {
        /*
         * CMD bit output
         */
        Ps2_SetCmd(
                ((tx >> bit) & 1U)
                ?
                1U
                :
                0U);


        Ps2_DelayUs(
                PS2_BIT_DELAY_US);


        /*
         * CLK LOW
         */
        IfxPort_setPinLow(
                PS2_CLK_PORT,
                PS2_CLK_PIN);


        Ps2_DelayUs(
                PS2_BIT_DELAY_US);


        /*
         * Read DATA
         */
        if (Ps2_ReadData() != 0U)
        {
            rx |=
                    (uint8)(
                            1U << bit);
        }


        /*
         * CLK HIGH
         */
        IfxPort_setPinHigh(
                PS2_CLK_PORT,
                PS2_CLK_PIN);


        Ps2_DelayUs(
                PS2_BIT_DELAY_US);
    }


    Ps2_SetCmd(1U);


    return rx;
}


/* ============================================================================================= */
/* TRANSACTION                                                                                   */
/* ============================================================================================= */

static void Ps2_Transaction(
        const uint8 *tx,
        uint8 *rx,
        uint8 len)
{
    uint8 i;


    if (
            (tx == 0)
            ||
            (rx == 0)
            ||
            (len == 0U)
       )
    {
        return;
    }


    /*
     * Idle
     */
    IfxPort_setPinHigh(
            PS2_CLK_PORT,
            PS2_CLK_PIN);

    Ps2_SetCmd(1U);


    /*
     * ATT LOW
     */
    IfxPort_setPinLow(
            PS2_ATT_PORT,
            PS2_ATT_PIN);


    Ps2_DelayUs(16U);


    for (i = 0U; i < len; i++)
    {
        rx[i] =
                Ps2_XferByte(
                        tx[i]);
    }


    /*
     * ATT HIGH
     */
    IfxPort_setPinHigh(
            PS2_ATT_PORT,
            PS2_ATT_PIN);


    Ps2_SetCmd(1U);


    Ps2_DelayUs(16U);
}


/* ============================================================================================= */
/* ANALOG MODE CONFIG                                                                            */
/* ============================================================================================= */

static void Ps2_ConfigAnalog(void)
{
    static const uint8 enterCfg[5] =
    {
        0x01U,
        0x43U,
        0x00U,
        0x01U,
        0x00U
    };


    static const uint8 setAna[9] =
    {
        0x01U,
        0x44U,
        0x00U,
        0x01U,
        0x03U,
        0x00U,
        0x00U,
        0x00U,
        0x00U
    };


    static const uint8 setMot[9] =
    {
        0x01U,
        0x4DU,
        0x00U,
        0x00U,
        0x01U,
        0xFFU,
        0xFFU,
        0xFFU,
        0xFFU
    };


    static const uint8 exitCfg[9] =
    {
        0x01U,
        0x43U,
        0x00U,
        0x00U,
        0x5AU,
        0x5AU,
        0x5AU,
        0x5AU,
        0x5AU
    };


    uint8 rx[PS2_PACKET_SIZE];

    uint8 retry;


    for (retry = 0U; retry < 3U; retry++)
    {
        Ps2_Transaction(
                enterCfg,
                rx,
                5U);

        Ps2_DelayMs(
                10U);


        Ps2_Transaction(
                setAna,
                rx,
                9U);

        Ps2_DelayMs(
                10U);


        Ps2_Transaction(
                setMot,
                rx,
                9U);

        Ps2_DelayMs(
                10U);


        Ps2_Transaction(
                exitCfg,
                rx,
                9U);

        Ps2_DelayMs(
                10U);
    }
}


/* ============================================================================================= */
/* PACKET CHECK                                                                                  */
/* ============================================================================================= */

static boolean Ps2_IsReceiverValidPacket(
        const uint8 *rx)
{
    if (rx == 0)
    {
        return FALSE;
    }


    if (
            !(
                (rx[1] == 0x41U)
                ||
                (rx[1] == 0x73U)
                ||
                (rx[1] == 0x79U)
             )
       )
    {
        return FALSE;
    }


    return
            (rx[2] == 0x5AU)
            ?
            TRUE
            :
            FALSE;
}


static boolean Ps2_IsDisconnectedPattern(
        const uint8 *rx)
{
    if (rx == 0)
    {
        return FALSE;
    }


    return
            (
                (rx[0] == 0xFFU)
                &&
                (rx[1] == 0x73U)
                &&
                (rx[2] == 0x5AU)
                &&
                (rx[3] == 0xFFU)
                &&
                (rx[4] == 0xFFU)
                &&
                (rx[5] == 0x80U)
                &&
                (rx[6] == 0x80U)
                &&
                (rx[7] == 0x80U)
                &&
                (rx[8] == 0x80U)
            )
            ?
            TRUE
            :
            FALSE;
}


/* ============================================================================================= */
/* BUTTON CONVERSION                                                                             */
/* ============================================================================================= */

static uint16 Ps2_ConvertPressedButtons(
        const uint8 *rx)
{
    uint16 released;


    released =
            (uint16)(
                    ((uint16)rx[4] << 8)
                    |
                    rx[3]);


    /*
     * PS2 button signals are active LOW.
     *
     * Convert:
     * 1 = pressed
     */
    return
            (uint16)(~released);
}


/* ============================================================================================= */
/* DEBUG COPY                                                                                    */
/* ============================================================================================= */

static void Ps2_CopyDebug(
        const uint8 *rx,
        boolean receiverValid,
        boolean padConnected)
{
    g_ps2Raw0 = rx[0];
    g_ps2Raw1 = rx[1];
    g_ps2Raw2 = rx[2];
    g_ps2Raw3 = rx[3];
    g_ps2Raw4 = rx[4];
    g_ps2Raw5 = rx[5];
    g_ps2Raw6 = rx[6];
    g_ps2Raw7 = rx[7];
    g_ps2Raw8 = rx[8];


    g_ps2Mode =
            rx[1];

    g_ps2Status =
            rx[2];


    g_ps2ReceiverAlive =
            (receiverValid != FALSE)
            ?
            1U
            :
            0U;


    g_ps2PadConnected =
            (padConnected != FALSE)
            ?
            1U
            :
            0U;


    g_ps2Buttons =
            Ps2_ConvertPressedButtons(
                    rx);


    /*
     * Analog mode
     */
    if (
            (padConnected != FALSE)
            &&
            (
                (rx[1] == 0x73U)
                ||
                (rx[1] == 0x79U)
            )
       )
    {
        g_ps2Rx =
                rx[5];

        g_ps2Ry =
                rx[6];

        g_ps2Lx =
                rx[7];

        g_ps2Ly =
                rx[8];


        /*
         * Left stick X axis is steering raw.
         */
        g_ps2SteeringRaw =
                g_ps2Lx;


        g_ps2SteeringAnalogActive =
                1U;
    }

    /*
     * Digital mode / disconnected
     */
    else
    {
        g_ps2Rx =
                0x80U;

        g_ps2Ry =
                0x80U;

        g_ps2Lx =
                0x80U;

        g_ps2Ly =
                0x80U;


        g_ps2SteeringRaw =
                128U;


        g_ps2SteeringAnalogActive =
                0U;
    }
}


/* ============================================================================================= */
/* INIT                                                                                          */
/* ============================================================================================= */

void Ps2Controller_Init(void)
{
    uint8 i;


    for (i = 0U; i < PS2_PACKET_SIZE; i++)
    {
        g_ps2Raw[i] =
                0xFFU;
    }


    /*
     * DATA input
     */
    IfxPort_setPinModeInput(
            PS2_DATA_PORT,
            PS2_DATA_PIN,
            IfxPort_InputMode_pullUp);


    /*
     * CMD output
     */
    IfxPort_setPinModeOutput(
            PS2_CMD_PORT,
            PS2_CMD_PIN,
            IfxPort_OutputMode_pushPull,
            IfxPort_OutputIdx_general);


    /*
     * ATT output
     */
    IfxPort_setPinModeOutput(
            PS2_ATT_PORT,
            PS2_ATT_PIN,
            IfxPort_OutputMode_pushPull,
            IfxPort_OutputIdx_general);


    /*
     * CLK output
     */
    IfxPort_setPinModeOutput(
            PS2_CLK_PORT,
            PS2_CLK_PIN,
            IfxPort_OutputMode_pushPull,
            IfxPort_OutputIdx_general);


    /*
     * Idle state
     */
    IfxPort_setPinHigh(
            PS2_CMD_PORT,
            PS2_CMD_PIN);

    IfxPort_setPinHigh(
            PS2_ATT_PORT,
            PS2_ATT_PIN);

    IfxPort_setPinHigh(
            PS2_CLK_PORT,
            PS2_CLK_PIN);


    g_ps2ReceiverAlive = 0U;
    g_ps2PadConnected = 0U;

    g_ps2Mode = 0xFFU;
    g_ps2Status = 0xFFU;

    g_ps2Buttons = 0U;

    g_ps2Rx = 0x80U;
    g_ps2Ry = 0x80U;
    g_ps2Lx = 0x80U;
    g_ps2Ly = 0x80U;

    g_ps2PollCount = 0U;
    g_ps2OkCount = 0U;
    g_ps2ErrCount = 0U;

    g_ps2LossCount = 0U;

    g_ps2SteeringRaw = 128U;
    g_ps2SteeringAnalogActive = 0U;


    /*
     * Receiver startup wait
     */
    Ps2_DelayMs(
            100U);


    /*
     * Configure analog mode
     */
    Ps2_ConfigAnalog();
}


/* ============================================================================================= */
/* 20 ms POLL                                                                                    */
/* ============================================================================================= */

void Ps2Controller_Poll20ms(void)
{
    static const uint8 poll[PS2_PACKET_SIZE] =
    {
        0x01U,
        0x42U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U,
        0x00U
    };


    boolean receiverValid;

    boolean padConnected;


    g_ps2PollCount++;


    Ps2_Transaction(
            poll,
            g_ps2Raw,
            PS2_PACKET_SIZE);


    receiverValid =
            Ps2_IsReceiverValidPacket(
                    g_ps2Raw);


    padConnected =
            (
                (receiverValid != FALSE)
                &&
                (Ps2_IsDisconnectedPattern(g_ps2Raw) == FALSE)
            )
            ?
            TRUE
            :
            FALSE;


    Ps2_CopyDebug(
            g_ps2Raw,
            receiverValid,
            padConnected);


    if (padConnected != FALSE)
    {
        g_ps2OkCount++;

        g_ps2LossCount =
                0U;
    }
    else
    {
        g_ps2ErrCount++;


        if (g_ps2LossCount < 0xFFU)
        {
            g_ps2LossCount++;
        }


        /*
         * Connection loss confirmed.
         */
        if (g_ps2LossCount >= PS2_LOSS_CONFIRM_CNT)
        {
            g_ps2PadConnected =
                    0U;

            g_ps2Buttons =
                    0U;

            g_ps2SteeringRaw =
                    128U;

            g_ps2SteeringAnalogActive =
                    0U;
        }
    }
}


/* ============================================================================================= */
/* PUBLIC GETTERS                                                                                */
/* ============================================================================================= */

boolean Ps2Controller_IsConnected(void)
{
    return
            (g_ps2PadConnected != 0U)
            ?
            TRUE
            :
            FALSE;
}


uint16 Ps2Controller_GetButtons(void)
{
    return
            g_ps2Buttons;
}


boolean Ps2Controller_IsSteeringAnalogActive(void)
{
    if (
            (g_ps2PadConnected != 0U)
            &&
            (
                (g_ps2Mode == 0x73U)
                ||
                (g_ps2Mode == 0x79U)
            )
       )
    {
        return TRUE;
    }


    return FALSE;
}


uint8 Ps2Controller_GetSteeringRaw(void)
{
    /*
     * Left stick X axis
     *
     * 0   = full left
     * 128 = center
     * 255 = full right
     */
    return
            g_ps2SteeringRaw;
}
