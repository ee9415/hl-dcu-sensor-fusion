CAN Bidirectional test (not validated on TASKING hardware yet)
RX unchanged: 0x200 STD 8B, 500kbit/s.
TX every 100ms: 0x101 requested steer angle int16 LE [0:1], raw ADC uint16 [2:3], ADC valid [4], mode [5], reserved [6:7].
TX every 100ms: 0x102 left wheel RPM int16 LE [0:1], right wheel RPM int16 [2:3], signed vehicle RPM int16 [4:5], RPM valid [6], mode [7].
Values use whole RPM/degree; raw ADC is NOT actual angle. No physical steering angle sensor calibration here.
On unconnected board RPM and ADC data are not trustworthy; check valid flags.
Original motor, steering, joystick, mode handling unchanged.
WARNING: imported project builds must be reviewed. Validate 5 existing warnings.
CanKing: add CAN channel source with UI Streams, 500k CAN. Observe 0x101/0x102.
