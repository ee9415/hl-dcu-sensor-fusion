
#include "ControlLoop.h"
#include "Can_VehicleControl.h"

#include "App_Config.h"
#include "Ps2_Controller.h"
#include "Speed_Calculate.h"
#include "Speed_Control.h"
#include "Steering_ADC.h"
#include "Steering_PWM.h"
#include "VehicleManager.h"

volatile uint32 g_controlLoopCount = 0U;
volatile uint32 g_controlLoop10msCount = 0U;
volatile uint32 g_controlLoop20msCount = 0U;
volatile uint32 g_controlLoop100msCount = 0U;

static uint8 g_adcDivider = 0U;
static uint8 g_ps2Divider = 0U;
static uint8 g_steeringDivider = 0U;
static uint8 g_speedPiDivider = 0U;

/* 0=MANUAL, 1=AUTO, 2=FAULT, 3=STOPPING */
#define CONTROL_MODE_STOPPING (3U)

void ControlLoop_Init(void)
{
    g_controlLoopCount = 0U;
    g_controlLoop10msCount = 0U;
    g_controlLoop20msCount = 0U;
    g_controlLoop100msCount = 0U;

    g_adcDivider = 0U;
    g_ps2Divider = 0U;
    g_steeringDivider = 0U;
    g_speedPiDivider = 0U;
}

void ControlLoop_5ms(void)
{
    g_controlLoopCount++;

    /* 20 ms: PS2 communication */
    g_ps2Divider++;

    if (g_ps2Divider >= PS2_TASK_DIV)
    {
        g_ps2Divider = 0U;
        Ps2Controller_Poll20ms();
        g_controlLoop20msCount++;
    }

    /* 5 ms: vehicle command / safety */
    VehicleManager_UpdateModeButtons5ms();

    if ((CanVehicleControl_IsAuto() != 0U) ||
        (g_canControlMode == CONTROL_MODE_STOPPING))
    {
        /* AUTO and STOPPING */
        CanVehicleControl_Update5ms();
    }
    else if (CanVehicleControl_IsFault() == 0U)
    {
        /* MANUAL */
        VehicleManager_Update5ms();
    }
    else
    {
        /* FAULT */
        SpeedControl_StopNow();
    }

    SpeedControl_UpdateCommand5ms();

    /* 10 ms: steering potentiometer */
    g_adcDivider++;

    if (g_adcDivider >= ADC_TASK_DIV)
    {
        g_adcDivider = 0U;
        SteeringAdc_Update10ms();
        g_controlLoop10msCount++;
    }

    /* 20 ms: steering movement */
    g_steeringDivider++;

    if (g_steeringDivider >= STEERING_TASK_DIV)
    {
        g_steeringDivider = 0U;
        SteeringPwm_Update20ms();
    }

    /* 100 ms: encoder RPM + PI */
    g_speedPiDivider++;

    if (g_speedPiDivider >= SPEED_PI_TASK_DIV)
    {
        g_speedPiDivider = 0U;
        SpeedCalc_Update100ms();
        SpeedControl_Update100ms();
        g_controlLoop100msCount++;
    }
}
